# 贡献指南

欢迎为IndusOpsAI项目做出贡献！

## 如何贡献

### 1. Fork项目
Fork项目到你的GitHub账户

### 2. 创建分支
```bash
git checkout -b feature/your-feature-name
```

### 3. 开发
- 遵循代码规范
- 添加必要的测试
- 更新相关文档

### 4. 提交代码
```bash
git commit -m "Add: your feature description"
```

### 5. 推送并创建Pull Request
```bash
git push origin feature/your-feature-name
```

在GitHub上创建Pull Request

## 代码规范

- 使用Python PEP 8代码风格
- 添加必要的注释和文档字符串
- 保持函数简洁，单一职责
- 添加适当的错误处理

## 提交信息规范

- `Add: ` 新功能
- `Fix: ` 修复bug
- `Update: ` 更新功能
- `Refactor: ` 代码重构
- `Docs: ` 文档更新

## 测试

在提交PR前，请确保：
- 所有测试通过
- 代码符合规范
- 没有引入新的警告

## 问题反馈

如发现问题，请在GitHub Issues中提交，包含：
- 问题描述
- 复现步骤
- 预期行为
- 实际行为
- 环境信息

## 许可

贡献的代码将遵循Apache 2.0许可证。



