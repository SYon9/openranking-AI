# IndusOpsAI 逻辑思维图

本文档使用 Mermaid 图表展示项目的整体逻辑架构和思维导图。

## 1. 系统整体架构图

```mermaid
graph TB
    subgraph "用户层"
        A[Web前端界面]
        B[API客户端]
    end
    
    subgraph "API层"
        C[Flask RESTful API]
        D[JWT认证]
    end
    
    subgraph "服务层"
        E[项目服务]
        F[开发者服务]
        G[匹配服务]
        H[问答服务]
    end
    
    subgraph "核心算法层"
        I[健康度评估模型]
        J[LSTM时序预测]
        K[GNN协作匹配]
        L[路径规划模型]
    end
    
    subgraph "数据层"
        M[数据采集]
        N[数据治理]
        O[数据存储]
    end
    
    subgraph "工具集成层"
        P[OpenDigger]
        Q[IoTDB]
        R[DataEase]
        S[MaxKB]
    end
    
    subgraph "存储层"
        T[SQLite]
        U[Redis]
        V[IoTDB时序库]
    end
    
    A --> C
    B --> C
    C --> D
    C --> E
    C --> F
    C --> G
    C --> H
    
    E --> I
    E --> J
    F --> L
    G --> K
    H --> S
    
    E --> M
    M --> N
    N --> O
    O --> T
    O --> U
    O --> V
    
    M --> P
    O --> Q
    E --> R
    H --> S
    
    I --> O
    J --> O
    K --> O
    L --> O
```

## 2. 数据流转逻辑图

```mermaid
flowchart TD
    Start([数据源]) --> A[OpenDigger API]
    Start --> B[GitHub API]
    Start --> C[Gitee API]
    
    A --> D[数据采集模块]
    B --> D
    C --> D
    
    D --> E[原始数据]
    E --> F[数据治理模块]
    
    F --> G[数据清洗]
    G --> H[数据脱敏]
    H --> I[数据标准化]
    I --> J[特征提取]
    
    J --> K[处理后数据]
    K --> L[数据存储模块]
    
    L --> M{数据类型}
    M -->|结构化数据| N[SQLite]
    M -->|缓存数据| O[Redis]
    M -->|时序数据| P[IoTDB]
    
    N --> Q[核心算法处理]
    O --> Q
    P --> Q
    
    Q --> R[健康度评估]
    Q --> S[时序预测]
    Q --> T[路径规划]
    Q --> U[协作匹配]
    
    R --> V[服务层]
    S --> V
    T --> V
    U --> V
    
    V --> W[API接口]
    W --> X[前端展示]
    W --> Y[API响应]
```

## 3. 核心功能模块思维图

```mermaid
mindmap
  root((IndusOpsAI))
    数据采集
      OpenDigger集成
      GitHub数据
      Gitee数据
      指标计算
    数据治理
      数据清洗
      数据脱敏
      标准化处理
      特征提取
    数据存储
      SQLite关系库
      Redis缓存
      IoTDB时序库
    健康度评估
      5+X维度模型
      熵权法权重
      动态加权
      风险识别
      优化建议
    LSTM预测
      趋势预测
      异常检测
      风险预警
    GNN匹配
      图构建
      节点嵌入
      相似度计算
      三方匹配
    路径规划
      技能提取
      任务匹配
      成长路径
      里程碑设定
    智能问答
      自然语言理解
      RAG检索
      知识库
      可视化建议
```

## 4. API接口逻辑图

```mermaid
graph LR
    subgraph "认证模块"
        A1[POST /auth/login]
        A2[POST /auth/register]
    end
    
    subgraph "项目管理"
        B1[GET /projects]
        B2[GET /projects/:repo]
        B3[GET /projects/:repo/health]
        B4[GET /projects/:repo/metrics]
        B5[POST /projects]
    end
    
    subgraph "开发者管理"
        C1[GET /developers/:id]
        C2[GET /developers/:id/path]
    end
    
    subgraph "智能匹配"
        D1[POST /match/project-contributor]
        D2[POST /match/contributor-contributor]
    end
    
    subgraph "智能问答"
        E1[POST /qa/ask]
    end
    
    A1 --> F[服务层]
    A2 --> F
    B1 --> F
    B2 --> F
    B3 --> F
    B4 --> F
    B5 --> F
    C1 --> F
    C2 --> F
    D1 --> F
    D2 --> F
    E1 --> F
    
    F --> G[核心算法]
    F --> H[数据层]
```

## 5. 健康度评估逻辑流程

```mermaid
flowchart TD
    Start([项目数据]) --> A[数据预处理]
    A --> B[指标提取]
    
    B --> C[代码活跃度]
    B --> D[Issue效能]
    B --> E[贡献者生态]
    B --> F[协作质量]
    B --> G[合规安全]
    B --> H[自定义维度]
    
    C --> I[熵权法权重计算]
    D --> I
    E --> I
    F --> I
    G --> I
    H --> I
    
    I --> J[动态加权]
    J --> K[维度得分计算]
    K --> L[总体健康度评分]
    
    L --> M{健康度等级}
    M -->|优秀 80-100| N[绿色]
    M -->|良好 60-80| O[黄色]
    M -->|一般 40-60| P[橙色]
    M -->|较差 <40| Q[红色]
    
    L --> R[风险识别]
    R --> S[优化建议生成]
    
    N --> T[结果输出]
    O --> T
    P --> T
    Q --> T
    S --> T
```

## 6. 开发者路径规划逻辑

```mermaid
flowchart TD
    Start([开发者ID]) --> A[获取开发者数据]
    A --> B[OpenRank分析]
    A --> C[贡献历史分析]
    
    B --> D[开发者层级分类]
    C --> E[技能标签提取]
    
    D --> F{层级判断}
    F -->|初级| G[新手路径]
    F -->|中级| H[进阶路径]
    F -->|高级| I[专家路径]
    
    E --> J[技能匹配]
    J --> K[项目需求分析]
    K --> L[任务推荐]
    
    G --> M[路径规划]
    H --> M
    I --> M
    L --> M
    
    M --> N[里程碑设定]
    N --> O[成长目标]
    O --> P[路径输出]
```

## 7. GNN协作匹配逻辑

```mermaid
flowchart TD
    Start([匹配请求]) --> A{匹配类型}
    
    A -->|项目-贡献者| B[项目特征提取]
    A -->|贡献者-贡献者| C[贡献者特征提取]
    
    B --> D[构建协作网络图]
    C --> D
    
    D --> E[节点: 项目]
    D --> F[节点: 贡献者]
    D --> G[节点: 机构]
    
    E --> H[边: 贡献关系]
    F --> H
    G --> H
    
    H --> I[GCN图卷积网络]
    I --> J[节点嵌入学习]
    J --> K[特征向量生成]
    
    K --> L[相似度计算]
    L --> M[Top-K匹配]
    M --> N[匹配结果输出]
```

## 8. 智能问答逻辑流程

```mermaid
sequenceDiagram
    participant U as 用户
    participant F as 前端界面
    participant A as API接口
    participant Q as 问答服务
    participant M as MaxKB
    participant D as 数据存储
    
    U->>F: 输入问题
    F->>A: POST /qa/ask
    A->>Q: 处理问题
    Q->>Q: 问题类型识别
    Q->>D: 查询相关数据
    D-->>Q: 返回数据
    Q->>M: RAG检索
    M-->>Q: 相关知识
    Q->>Q: 生成回答
    Q->>Q: 生成可视化建议
    Q-->>A: 返回结果
    A-->>F: JSON响应
    F-->>U: 显示结果
```

## 9. 完整业务流程图

```mermaid
flowchart TB
    subgraph "用户交互"
        U1[访问前端界面]
        U2[输入服务地址]
        U3[选择功能模块]
    end
    
    subgraph "API请求处理"
        A1[接收HTTP请求]
        A2[JWT认证验证]
        A3[路由分发]
    end
    
    subgraph "服务层处理"
        S1[项目服务]
        S2[开发者服务]
        S3[匹配服务]
        S4[问答服务]
    end
    
    subgraph "核心算法"
        C1[健康度评估]
        C2[LSTM预测]
        C3[GNN匹配]
        C4[路径规划]
    end
    
    subgraph "数据操作"
        D1[数据采集]
        D2[数据治理]
        D3[数据存储]
        D4[数据查询]
    end
    
    subgraph "工具集成"
        T1[OpenDigger]
        T2[IoTDB]
        T3[DataEase]
        T4[MaxKB]
    end
    
    U1 --> U2
    U2 --> U3
    U3 --> A1
    A1 --> A2
    A2 --> A3
    
    A3 --> S1
    A3 --> S2
    A3 --> S3
    A3 --> S4
    
    S1 --> C1
    S1 --> C2
    S2 --> C4
    S3 --> C3
    S4 --> T4
    
    S1 --> D1
    D1 --> D2
    D2 --> D3
    D3 --> D4
    
    D1 --> T1
    D3 --> T2
    S1 --> T3
    
    C1 --> D3
    C2 --> D3
    C3 --> D3
    C4 --> D3
    
    D4 --> S1
    D4 --> S2
    D4 --> S3
    D4 --> S4
    
    S1 --> A3
    S2 --> A3
    S3 --> A3
    S4 --> A3
    
    A3 --> U1
```

## 10. 技术栈思维图

```mermaid
mindmap
  root((技术栈))
    Web框架
      Flask 3.0
      Flask-RESTful
      Flask-CORS
      Flask-JWT
    数据存储
      SQLite
      Redis
      IoTDB
    机器学习
      PyTorch
      scikit-learn
      PyTorch Geometric
    NLP
      jieba
      HanLP
    数据处理
      pandas
      numpy
      scipy
    工具集成
      OpenDigger API
      DataEase API
      MaxKB API
      IoTDB Client
```

## 11. 部署架构图

```mermaid
graph TB
    subgraph "客户端"
        A[Web浏览器]
        B[API客户端]
    end
    
    subgraph "反向代理层"
        C[Nginx]
    end
    
    subgraph "应用层"
        D[Gunicorn/Waitress]
        E[Flask应用]
    end
    
    subgraph "服务层"
        F[项目服务]
        G[开发者服务]
        H[匹配服务]
        I[问答服务]
    end
    
    subgraph "算法层"
        J[健康度评估]
        K[LSTM预测]
        L[GNN匹配]
        M[路径规划]
    end
    
    subgraph "数据层"
        N[SQLite]
        O[Redis]
        P[IoTDB]
    end
    
    subgraph "外部服务"
        Q[OpenDigger]
        R[DataEase]
        S[MaxKB]
    end
    
    A --> C
    B --> C
    C --> D
    D --> E
    E --> F
    E --> G
    E --> H
    E --> I
    
    F --> J
    F --> K
    G --> M
    H --> L
    
    F --> N
    F --> O
    F --> P
    
    F --> Q
    F --> R
    I --> S
```

## 12. 核心算法详细流程

```mermaid
flowchart TD
    subgraph "健康度评估流程"
        A1[项目数据] --> A2[5个核心维度]
        A2 --> A3[熵权法计算权重]
        A3 --> A4[动态加权评分]
        A4 --> A5[总体健康度]
        A5 --> A6[风险识别]
        A6 --> A7[优化建议]
    end
    
    subgraph "LSTM预测流程"
        B1[历史健康度数据] --> B2[数据预处理]
        B2 --> B3[序列构建]
        B3 --> B4[LSTM模型训练]
        B4 --> B5[趋势预测]
        B5 --> B6[异常检测]
        B6 --> B7[风险预警]
    end
    
    subgraph "GNN匹配流程"
        C1[项目/贡献者数据] --> C2[构建协作网络图]
        C2 --> C3[GCN节点嵌入]
        C3 --> C4[特征向量]
        C4 --> C5[相似度计算]
        C5 --> C6[Top-K匹配]
    end
    
    subgraph "路径规划流程"
        D1[开发者数据] --> D2[层级分类]
        D2 --> D3[技能提取]
        D3 --> D4[任务匹配]
        D4 --> D5[路径生成]
        D5 --> D6[里程碑设定]
    end
```

## 使用说明

### 查看图表

1. **在支持 Mermaid 的 Markdown 查看器中**（如 GitHub、GitLab、VS Code 的 Markdown Preview Enhanced 插件）
   - 图表会自动渲染为可视化图形

2. **在线查看**
   - 访问 https://mermaid.live/
   - 复制 Mermaid 代码到编辑器
   - 查看渲染结果

3. **导出为图片**
   - 使用 Mermaid CLI: `mmdc -i LOGIC_DIAGRAM.md -o diagram.png`
   - 或使用在线工具转换为 PNG/SVG

4. **文本版本**
   - 如果无法查看 Mermaid 图表，请查看 [文本版思维图](LOGIC_DIAGRAM_TEXT.md)

### 图表说明

- **系统整体架构图**：展示系统的分层架构和模块关系
- **数据流转逻辑图**：展示数据从采集到展示的完整流程
- **核心功能模块思维图**：以思维导图形式展示所有核心功能
- **API接口逻辑图**：展示所有API接口的分类和关系
- **健康度评估逻辑流程**：详细展示健康度评估的算法流程
- **开发者路径规划逻辑**：展示路径规划的决策流程
- **GNN协作匹配逻辑**：展示图神经网络匹配的流程
- **智能问答逻辑流程**：展示问答服务的交互流程
- **完整业务流程图**：展示从用户请求到响应的完整流程
- **技术栈思维图**：展示使用的技术栈
- **部署架构图**：展示生产环境的部署架构
- **核心算法详细流程**：展示四个核心算法的详细流程

## 图表更新

如需更新图表，请修改对应的 Mermaid 代码块。Mermaid 语法参考：https://mermaid.js.org/

