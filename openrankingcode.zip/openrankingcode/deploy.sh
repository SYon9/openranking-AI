#!/bin/bash
# IndusOpsAI 一键部署脚本 (Linux/macOS)
# 使用方法: bash deploy.sh

set -e  # 遇到错误立即退出

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# 打印函数
print_step() {
    echo -e "${BLUE}${BOLD}>>> $1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# 检查是否在项目根目录
if [ ! -f "requirements.txt" ]; then
    print_error "请在项目根目录运行此脚本"
    exit 1
fi

echo "============================================================"
echo -e "${BOLD}IndusOpsAI 一键部署脚本${NC}"
echo "============================================================"
echo

# 1. 检查 Python 版本
print_step "检查 Python 版本..."
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

if [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -ge 9 ]; then
    print_success "Python 版本: $PYTHON_VERSION"
else
    print_error "Python 版本 $PYTHON_VERSION 不符合要求（需要 3.9+）"
    exit 1
fi

# 2. 升级 pip
print_step "升级 pip、setuptools 和 wheel..."
python3 -m pip install --upgrade pip setuptools wheel
print_success "pip 升级完成"

# 3. 创建虚拟环境
print_step "创建虚拟环境..."
if [ -d "venv" ]; then
    print_warning "虚拟环境已存在"
    read -p "是否删除并重新创建？(y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf venv
    else
        print_success "使用现有虚拟环境"
    fi
fi

if [ ! -d "venv" ]; then
    python3 -m venv venv
    print_success "虚拟环境创建成功"
fi

# 4. 激活虚拟环境并安装依赖
print_step "安装项目依赖..."
source venv/bin/activate
pip install -r requirements.txt
print_success "核心依赖安装完成"

# 5. 询问是否安装开发依赖
read -p "是否安装开发依赖？(y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    print_step "安装开发依赖..."
    pip install -r requirements-dev.txt
    print_success "开发依赖安装完成"
fi

# 6. 设置环境变量文件
print_step "配置环境变量..."
if [ -f ".env" ]; then
    print_warning ".env 文件已存在"
    read -p "是否覆盖现有 .env 文件？(y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if [ -f ".env.example" ]; then
            cp .env.example .env
            print_success ".env 文件已创建（基于 .env.example）"
        else
            cat > .env << EOF
# IndusOpsAI 环境变量配置
# 生产环境请修改 JWT_SECRET_KEY
JWT_SECRET_KEY=indusopsai-secret-key-change-in-production
JWT_ACCESS_TOKEN_EXPIRES=3600
LOG_LEVEL=INFO
EOF
            print_success ".env 文件已创建（基本配置）"
        fi
    fi
else
    if [ -f ".env.example" ]; then
        cp .env.example .env
        print_success ".env 文件已创建（基于 .env.example）"
    else
        cat > .env << EOF
# IndusOpsAI 环境变量配置
# 生产环境请修改 JWT_SECRET_KEY
JWT_SECRET_KEY=indusopsai-secret-key-change-in-production
JWT_ACCESS_TOKEN_EXPIRES=3600
LOG_LEVEL=INFO
EOF
        print_success ".env 文件已创建（基本配置）"
    fi
fi
print_warning "请编辑 .env 文件配置相关参数（如 JWT_SECRET_KEY 等）"

# 7. 初始化数据库
print_step "初始化数据库..."
if python scripts/init_db.py; then
    print_success "数据库初始化完成"
else
    print_warning "数据库初始化失败，可以稍后手动运行: python scripts/init_db.py"
fi

# 8. 验证部署
print_step "验证部署..."
if python scripts/check_dependencies.py; then
    print_success "部署验证通过"
else
    print_warning "部分依赖可能未正确安装，请检查"
fi

# 9. 打印后续步骤
echo
echo "============================================================"
echo -e "${BOLD}${GREEN}部署完成！${NC}"
echo "============================================================"
echo
echo "后续步骤："
echo "1. 编辑 .env 文件配置相关参数（特别是 JWT_SECRET_KEY）"
echo "2. 启动服务："
echo "   - 开发环境: source venv/bin/activate && python run.py"
echo "   - 生产环境: source venv/bin/activate && gunicorn -c gunicorn.conf.py src.api.app:create_app"
echo "3. 访问服务: http://localhost:5000"
echo "4. 健康检查: http://localhost:5000/health"
echo
echo "更多信息请查看 README.md 和 DEPENDENCIES.md"
echo "============================================================"



