# 系统架构文档

## 1. 整体架构

IndusOpsAI采用分层微服务架构，包含以下层次：

### 1.1 数据层（Data Layer）
- **数据采集模块** (`data_layer/collector.py`): 从OpenDigger、GitHub、Gitee等数据源采集数据
- **数据治理模块** (`data_layer/processor.py`): 数据清洗、脱敏、标准化、特征提取
- **数据存储模块** (`data_layer/storage.py`): SQLite关系数据库、Redis缓存、IoTDB时序数据库

### 1.2 核心算法层（Core Layer）
- **健康度评估模型** (`core/health_assessment.py`): 5+X动态加权健康度评估，熵权法+AHP权重计算
- **LSTM时序预测模型** (`core/forecast_model.py`): 健康度趋势预测与风险预警
- **GNN协作匹配引擎** (`core/matching_engine.py`): 基于图神经网络的协作匹配
- **贡献路径规划模型** (`core/path_planning.py`): 技能-任务-成长三维路径规划

### 1.3 工具集成层（Integration Layer）
- **OpenDigger客户端** (`integrations/opendigger_client.py`): OpenDigger API集成与指标计算
- **IoTDB客户端** (`integrations/iotdb_client.py`): 时序数据存储与查询
- **DataEase客户端** (`integrations/dataease_client.py`): 可视化仪表板创建与管理
- **MaxKB客户端** (`integrations/maxkb_client.py`): 智能问答与知识库管理

### 1.4 服务层（Service Layer）
- **项目服务** (`services/project_service.py`): 项目数据管理与健康度评估
- **开发者服务** (`services/developer_service.py`): 开发者档案管理与路径规划
- **匹配服务** (`services/matching_service.py`): 协作匹配服务
- **问答服务** (`services/qa_service.py`): 智能问答服务

### 1.5 API层（API Layer）
- **RESTful API** (`api/routes.py`): 提供HTTP API接口
- **认证授权** (`api/app.py`): JWT认证与权限管理

## 2. 核心创新点实现

### 2.1 时序驱动的健康度评估模型

**实现位置**: `core/health_assessment.py`

**核心算法**:
- 熵权法权重计算：基于指标区分度动态计算权重
- 5+X维度评估：代码活跃度、Issue效能、贡献者生态、协作质量、合规安全 + 自定义维度
- 风险识别：基于阈值和趋势分析识别风险点
- 优化建议生成：基于评估结果自动生成改进建议

### 2.2 LSTM时序预测

**实现位置**: `core/forecast_model.py`

**核心功能**:
- 健康度趋势预测：基于历史数据预测未来健康度
- 异常检测：识别健康度异常波动
- 风险预警：提前预警潜在问题

### 2.3 GNN协作匹配

**实现位置**: `core/matching_engine.py`

**核心算法**:
- 图构建：项目-贡献者-机构三方网络图
- GCN模型：图卷积网络学习节点嵌入
- 相似度计算：基于嵌入向量计算匹配度

### 2.4 贡献路径规划

**实现位置**: `core/path_planning.py`

**核心功能**:
- 开发者层级分类：基于OpenRank和贡献数分类
- 技能标签提取：从贡献历史中提取技能
- 任务匹配：基于技能和项目需求匹配任务
- 里程碑设定：设定成长目标与里程碑

## 3. 数据流转

```
数据源 (OpenDigger/GitHub/Gitee)
    ↓
数据采集 (collector.py)
    ↓
数据治理 (processor.py)
    ↓
数据存储 (storage.py)
    ├─ SQLite (结构化数据)
    ├─ Redis (缓存)
    └─ IoTDB (时序数据)
    ↓
核心算法处理
    ├─ 健康度评估
    ├─ 时序预测
    ├─ 路径规划
    └─ 协作匹配
    ↓
工具集成
    ├─ DataEase (可视化)
    └─ MaxKB (问答)
    ↓
API服务
    ↓
前端展示
```

## 4. 技术栈

### 后端
- **Web框架**: Flask + Flask-RESTful
- **数据库**: SQLite, Redis, IoTDB
- **机器学习**: PyTorch, scikit-learn
- **图神经网络**: PyTorch Geometric
- **NLP**: jieba, HanLP

### 工具集成
- **OpenDigger**: REST API集成
- **DataEase**: REST API集成
- **MaxKB**: REST API集成
- **IoTDB**: Python客户端集成

## 5. 扩展性设计

### 5.1 模块化设计
- 各模块通过接口交互，低耦合
- 易于替换或扩展单个模块

### 5.2 插件化架构
- 支持自定义健康度维度
- 支持自定义匹配算法
- 支持自定义可视化组件

### 5.3 微服务架构
- 各服务独立部署
- 支持水平扩展
- 支持服务降级

## 6. 安全性

- JWT认证授权
- 数据脱敏处理
- API限流保护
- 数据加密存储

## 7. 性能优化

- Redis缓存高频查询
- 异步数据处理
- 批量数据操作
- 增量数据更新



