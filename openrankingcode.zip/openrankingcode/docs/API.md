# API文档

## 基础信息

- **Base URL**: `http://localhost:5000/api/v1`
- **认证方式**: JWT Bearer Token

## 认证接口

### 登录
```
POST /auth/login
```

**请求体**:
```json
{
  "username": "user123",
  "password": "password123"
}
```

**响应**:
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "Bearer"
}
```

### 注册
```
POST /auth/register
```

**请求体**:
```json
{
  "username": "user123",
  "password": "password123",
  "email": "user@example.com"
}
```

## 项目接口

### 获取项目列表
```
GET /projects
```

**响应**:
```json
{
  "projects": [
    {
      "repo": "apache/iotdb",
      "name": "iotdb",
      "metrics": {...}
    }
  ]
}
```

### 添加项目
```
POST /projects
Authorization: Bearer <token>
```

**请求体**:
```json
{
  "repo": "apache/iotdb"
}
```

### 获取项目详情
```
GET /projects/{repo}
```

**响应**:
```json
{
  "repo": "apache/iotdb",
  "name": "iotdb",
  "metrics": {
    "openrank": {...},
    "activity": {...}
  },
  "contributors": [...]
}
```

### 获取项目健康度
```
GET /projects/{repo}/health
```

**响应**:
```json
{
  "overall_score": 85.5,
  "dimension_scores": {
    "code_activity": 0.8,
    "issue_efficiency": 0.75,
    ...
  },
  "risks": [...],
  "suggestions": [...]
}
```

### 获取项目指标
```
GET /projects/{repo}/metrics
```

## 开发者接口

### 获取开发者档案
```
GET /developers/{developer_id}
```

**响应**:
```json
{
  "id": "developer123",
  "openrank": 45.2,
  "contributions": 120,
  "skill_tags": ["Python", "Java", "时序数据库"]
}
```

### 获取贡献路径
```
GET /developers/{developer_id}/path?project_repo=apache/iotdb&target_openrank=100
```

**响应**:
```json
{
  "developer_level": "intermediate",
  "current_openrank": 45.2,
  "recommended_tasks": [...],
  "path": [...],
  "milestones": [...]
}
```

## 匹配接口

### 项目-贡献者匹配
```
POST /match/project-contributor
```

**请求体**:
```json
{
  "project_repo": "apache/iotdb",
  "top_k": 10
}
```

**响应**:
```json
{
  "matches": [
    {
      "contributor_id": "contributor123",
      "match_score": 0.85,
      "contributions": 150
    }
  ]
}
```

### 贡献者-贡献者匹配
```
POST /match/contributor-contributor
```

**请求体**:
```json
{
  "contributor_id": "contributor123",
  "top_k": 10
}
```

## 问答接口

### 智能问答
```
POST /qa/ask
```

**请求体**:
```json
{
  "question": "Apache IoTDB的OpenRank趋势如何？",
  "project_repo": "apache/iotdb"
}
```

**响应**:
```json
{
  "answer": "根据数据显示，Apache IoTDB的OpenRank在最近6个月呈上升趋势...",
  "sources": [...],
  "visualization": {
    "type": "line",
    "suggestion": "建议使用折线图展示趋势变化"
  }
}
```



