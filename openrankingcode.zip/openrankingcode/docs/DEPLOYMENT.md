# IndusOpsAI 部署文档

## 1. 部署概述

本文档详细说明IndusOpsAI系统的部署步骤，包括环境准备、依赖安装、配置设置、服务启动等。

## 2. 系统要求

### 2.1 硬件要求

**最低配置**：
- CPU：2核
- 内存：4GB
- 磁盘：20GB可用空间

**推荐配置**：
- CPU：4核或以上
- 内存：8GB或以上
- 磁盘：50GB可用空间（用于数据存储）

### 2.2 软件要求

**操作系统**：
- Linux（Ubuntu 20.04+、CentOS 7+、Debian 10+）
- macOS 10.15+
- Windows 10/11（需要WSL或Docker）

**运行时环境**：
- Python 3.9 或更高版本（推荐 3.9, 3.10, 3.11 或 3.12）
- pip 23.0+（推荐使用最新版本）
- git 2.20+

**可选依赖**：
- Redis 6.0+（用于缓存，可选）
- Apache IoTDB 1.2+（用于时序数据存储，可选，需要先安装 thrift>=0.13）
- Node.js 16+（如需前端开发）

## 2.3 依赖管理

### 依赖文件说明

项目包含以下依赖文件：
- **requirements.txt**: 核心生产依赖，包含运行项目必需的所有包
- **requirements-dev.txt**: 开发环境依赖，包含测试、代码质量检查等工具
- **requirements-optional.txt**: 可选依赖，根据实际需求选择性安装

### 核心依赖说明

**数据处理与科学计算**：
- `pandas>=2.0.0,<2.2.0`: 数据分析库
- `numpy>=1.24.0,<2.0.0`: 数值计算库
- `scipy>=1.10.0,<1.13.0`: 科学计算库
- `scikit-learn>=1.3.0,<1.5.0`: 机器学习库

**Web框架**：
- `flask>=3.0.0,<4.0.0`: Web应用框架
- `flask-cors>=4.0.0,<5.0.0`: 跨域资源共享支持
- `flask-jwt-extended>=4.6.0,<5.0.0`: JWT认证支持
- `flask-restful>=0.3.10,<0.4.0`: RESTful API支持

**数据库与缓存**：
- `redis>=5.0.0,<6.0.0`: Redis缓存客户端
- `apache-iotdb>=1.0.0,<2.0.0`: IoTDB时序数据库客户端（可选，在 requirements-optional.txt 中）

**机器学习与深度学习**：
- `torch>=2.0.0,<2.3.0`: PyTorch深度学习框架
- `torch-geometric>=2.4.0,<3.0.0`: 图神经网络库

**注意**: PyTorch 的安装可能需要根据系统架构选择，建议：
- CPU 版本：`pip install torch torch-geometric --index-url https://download.pytorch.org/whl/cpu`
- GPU 版本：访问 [PyTorch 官网](https://pytorch.org/get-started/locally/) 获取对应命令

**NLP处理**：
- `jieba>=0.42.0,<0.43.0`: 中文分词库

**HTTP请求**：
- `requests>=2.31.0,<3.0.0`: HTTP请求库

**Windows WSGI服务器**：
- `waitress>=2.1.0,<3.0.0`: Windows兼容的WSGI服务器

### IoTDB安装说明

IoTDB是可选依赖，如果需要使用时序数据库功能，需要安装：

1. **安装thrift依赖**（IoTDB需要）：
```bash
pip install thrift>=0.13
```

2. **安装IoTDB客户端**：
```bash
pip install apache-iotdb>=1.0.0,<2.0.0
```

或使用可选依赖文件：
```bash
pip install -r requirements-optional.txt
```

3. **配置IoTDB连接**：
在 `.env` 文件中配置：
```
IOTDB_HOST=localhost
IOTDB_PORT=6667
IOTDB_USER=root
IOTDB_PASSWORD=root
```

## 3. 安装步骤

### 3.1 获取代码

```bash
# 克隆仓库
git clone https://github.com/your-org/IndusOpsAI.git
cd IndusOpsAI

# 或下载zip包并解压
```

### 3.2 Python环境配置

#### 3.2.1 使用虚拟环境（推荐）

```bash
# 创建虚拟环境
python3 -m venv venv

# 激活虚拟环境
# Linux/macOS:
source venv/bin/activate
# Windows:
venv\Scripts\activate
```

#### 3.2.2 安装Python依赖

```bash
# 升级pip
pip install --upgrade pip

# 安装依赖包
pip install -r requirements.txt

# 如果安装速度慢，可以使用国内镜像
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

#### 3.2.3 验证安装

```bash
# 检查Python版本
python --version  # 应该是 3.9+

# 检查关键包
python -c "import flask, torch, pandas; print('依赖安装成功')"
```

### 3.3 可选依赖安装

#### 3.3.1 Redis安装（可选）

**Ubuntu/Debian**：
```bash
sudo apt update
sudo apt install redis-server
sudo systemctl start redis
sudo systemctl enable redis
```

**macOS**：
```bash
brew install redis
brew services start redis
```

**Docker方式**：
```bash
docker run -d -p 6379:6379 --name redis redis:6-alpine
```

**验证Redis**：
```bash
redis-cli ping
# 应返回 PONG
```

#### 3.3.2 IoTDB安装（可选）

**下载IoTDB**：
```bash
# 访问 https://iotdb.apache.org/Download/
# 下载对应版本的IoTDB
wget https://downloads.apache.org/iotdb/1.2.0/apache-iotdb-1.2.0-server-bin.zip
unzip apache-iotdb-1.2.0-server-bin.zip
cd apache-iotdb-1.2.0-server-bin
```

**启动IoTDB**：
```bash
# Linux/macOS
sbin/start-server.sh

# Windows
sbin\start-server.bat
```

**验证IoTDB**：
```bash
# 检查端口6667是否监听
netstat -an | grep 6667
```

**Docker方式**：
```bash
docker run -d -p 6667:6667 -p 31999:31999 \
  --name iotdb apache/iotdb:1.2.0
```

### 3.4 配置环境变量

#### 3.4.1 创建配置文件

```bash
# 复制环境变量模板
cp .env.example .env

# 编辑配置文件
nano .env  # 或使用其他编辑器
```

#### 3.4.2 配置说明

**基础配置**：
```bash
# 数据库配置
SQLITE_DB_PATH=./data/indusopsai.db
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0

# IoTDB配置
IOTDB_HOST=localhost
IOTDB_PORT=6667
IOTDB_USER=root
IOTDB_PASSWORD=root
```

**API密钥配置**：
```bash
# OpenDigger配置（如需使用）
OPENDIGGER_API_URL=https://api.opendigger.cn
OPENDIGGER_API_KEY=your_api_key_here

# DataEase配置（如需使用）
DATAEASE_API_URL=http://localhost:8080
DATAEASE_USERNAME=admin
DATAEASE_PASSWORD=admin

# MaxKB配置（如需使用）
MAXKB_API_URL=http://localhost:8081
MAXKB_API_KEY=your_maxkb_key
```

**安全配置**：
```bash
# JWT配置（生产环境必须修改）
JWT_SECRET_KEY=your_secret_key_here_change_in_production
JWT_ACCESS_TOKEN_EXPIRES=3600

# 日志配置
LOG_LEVEL=INFO
LOG_FILE=./logs/indusopsai.log
```

### 3.5 初始化数据库

```bash
# 创建必要的目录
mkdir -p data/raw data/processed data/cache logs models

# 初始化SQLite数据库
python scripts/init_db.py

# 验证数据库
ls -lh data/indusopsai.db
```

### 3.6 运行演示（可选）

```bash
# 运行演示脚本，验证系统功能
# 演示功能已集成到前端界面，访问 http://localhost:5000 即可使用
```

## 4. 服务启动

### 4.1 开发环境启动

#### 4.1.1 直接启动

```bash
# 方式1：使用启动脚本
python run.py

# 方式2：直接运行Flask应用
python src/api/app.py

# 服务将在 http://localhost:5000 启动
```

#### 4.1.2 使用Flask CLI

```bash
export FLASK_APP=src/api/app.py
export FLASK_ENV=development
flask run --host=0.0.0.0 --port=5000
```

### 4.2 生产环境部署

#### 4.2.1 使用Gunicorn（推荐）

**安装Gunicorn**：
```bash
pip install gunicorn
```

**启动服务**：
```bash
# 基础启动（注意：不需要括号，gunicorn 需要可调用对象）
gunicorn -w 4 -b 0.0.0.0:5000 "src.api.app:create_app"

# 推荐配置
gunicorn -w 4 -b 0.0.0.0:5000 \
  --access-logfile logs/access.log \
  --error-logfile logs/error.log \
  --log-level info \
  --timeout 120 \
  "src.api.app:create_app"
```

**配置文件方式（推荐）**：

创建 `gunicorn.conf.py`：
```python
# gunicorn.conf.py
bind = "0.0.0.0:5000"
workers = 4
worker_class = "sync"
worker_connections = 1000
timeout = 120
keepalive = 5
accesslog = "logs/access.log"
errorlog = "logs/error.log"
loglevel = "info"
```

启动命令（注意：不需要括号）：
```bash
gunicorn -c gunicorn.conf.py "src.api.app:create_app"
```

#### 4.2.2 使用systemd管理服务（Linux）

**创建服务文件** `/etc/systemd/system/indusopsai.service`：
```ini
[Unit]
Description=IndusOpsAI Service
After=network.target

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=/opt/indusopsai
Environment="PATH=/opt/indusopsai/venv/bin"
ExecStart=/opt/indusopsai/venv/bin/gunicorn -c gunicorn.conf.py "src.api.app:create_app"
Restart=always

[Install]
WantedBy=multi-user.target
```

**启动服务**：
```bash
sudo systemctl daemon-reload
sudo systemctl start indusopsai
sudo systemctl enable indusopsai
sudo systemctl status indusopsai
```

#### 4.2.3 使用Docker部署

**创建Dockerfile**：
```dockerfile
FROM python:3.9-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# 复制依赖文件
COPY requirements.txt .

# 安装Python依赖
RUN pip install --no-cache-dir -r requirements.txt

# 复制应用代码
COPY . .

# 创建必要目录
RUN mkdir -p data logs

# 暴露端口
EXPOSE 5000

# 启动命令（注意：不需要括号）
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "src.api.app:create_app"]
```

**构建镜像**：
```bash
docker build -t indusopsai:latest .
```

**运行容器**：
```bash
docker run -d \
  --name indusopsai \
  -p 5000:5000 \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/logs:/app/logs \
  --env-file .env \
  indusopsai:latest
```

**使用docker-compose**（推荐）：

创建 `docker-compose.yml`：
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
    env_file:
      - .env
    depends_on:
      - redis
      - iotdb
    restart: unless-stopped

  redis:
    image: redis:6-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped

  iotdb:
    image: apache/iotdb:1.2.0
    ports:
      - "6667:6667"
      - "31999:31999"
    volumes:
      - iotdb_data:/iotdb/data
    restart: unless-stopped

volumes:
  redis_data:
  iotdb_data:
```

启动服务：
```bash
docker-compose up -d
```

查看日志：
```bash
docker-compose logs -f
```

## 5. Nginx反向代理配置

### 5.1 安装Nginx

```bash
# Ubuntu/Debian
sudo apt install nginx

# CentOS/RHEL
sudo yum install nginx
```

### 5.2 配置Nginx

创建配置文件 `/etc/nginx/sites-available/indusopsai`：
```nginx
server {
    listen 80;
    server_name your-domain.com;

    # 静态文件（如有前端）
    location /static/ {
        alias /opt/indusopsai/frontend/dist/static/;
    }

    # API代理
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # WebSocket支持（如需要）
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    # 根路径
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

启用配置：
```bash
sudo ln -s /etc/nginx/sites-available/indusopsai /etc/nginx/sites-enabled/
sudo nginx -t  # 测试配置
sudo systemctl reload nginx
```

### 5.3 SSL证书配置（HTTPS）

使用Let's Encrypt：
```bash
# 安装certbot
sudo apt install certbot python3-certbot-nginx

# 申请证书
sudo certbot --nginx -d your-domain.com

# 自动续期
sudo certbot renew --dry-run
```

## 6. 验证部署

### 6.1 健康检查

```bash
# 检查服务状态
curl http://localhost:5000/health

# 应该返回：
# {"status": "healthy"}
```

### 6.2 API测试

```bash
# 测试API根路径
curl http://localhost:5000/

# 测试项目列表
curl http://localhost:5000/api/v1/projects

# 测试登录
curl -X POST http://localhost:5000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "test", "password": "test"}'
```

### 6.3 日志检查

```bash
# 查看应用日志
tail -f logs/indusopsai.log

# 查看Nginx日志（如使用）
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log

# 查看systemd日志（如使用）
journalctl -u indusopsai -f
```

## 7. 数据备份

### 7.1 数据库备份

```bash
# SQLite备份
cp data/indusopsai.db data/backup/indusopsai_$(date +%Y%m%d_%H%M%S).db

# Redis备份（如使用）
redis-cli SAVE
cp /var/lib/redis/dump.rdb backup/redis_$(date +%Y%m%d_%H%M%S).rdb
```

### 7.2 自动化备份脚本

创建 `scripts/backup.sh`：
```bash
#!/bin/bash
BACKUP_DIR="/opt/indusopsai/backup"
DATE=$(date +%Y%m%d_%H%M%S)

# 创建备份目录
mkdir -p $BACKUP_DIR

# 备份数据库
cp data/indusopsai.db $BACKUP_DIR/indusopsai_$DATE.db

# 备份配置文件
tar -czf $BACKUP_DIR/config_$DATE.tar.gz .env

# 删除7天前的备份
find $BACKUP_DIR -name "*.db" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup completed: $DATE"
```

添加到crontab：
```bash
# 每天凌晨2点备份
0 2 * * * /opt/indusopsai/scripts/backup.sh  # 需要先创建备份脚本
```

## 8. 性能优化

### 8.1 应用层优化

**Gunicorn配置优化**：
```python
# gunicorn.conf.py
workers = (2 * CPU核心数) + 1
worker_class = "gevent"  # 异步worker（需安装gevent）
worker_connections = 1000
max_requests = 1000  # 防止内存泄漏
max_requests_jitter = 100
```

### 8.2 数据库优化

**SQLite优化**：
```python
# 在storage.py中启用WAL模式
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA cache_size=10000;
PRAGMA temp_store=memory;
```

### 8.3 缓存优化

**Redis配置优化**：
```bash
# redis.conf
maxmemory 256mb
maxmemory-policy allkeys-lru
```

## 9. 监控和维护

### 9.1 日志监控

使用logrotate管理日志：
```bash
# /etc/logrotate.d/indusopsai
/opt/indusopsai/logs/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0640 www-data www-data
}
```

### 9.2 性能监控

安装Prometheus + Grafana（可选）：
```yaml
# docker-compose.monitoring.yml
version: '3.8'

services:
  prometheus:
    image: prom/prometheus
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    ports:
      - "9090:9090"

  grafana:
    image: grafana/grafana
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
```

### 9.3 定期维护

**数据清理**：
- 定期清理过期缓存
- 归档旧数据
- 清理临时文件

**系统更新**：
- 定期更新依赖包
- 更新安全补丁
- 检查日志错误

## 10. 故障排查

### 10.1 常见问题

**问题1：端口被占用**
```bash
# 查找占用端口的进程
lsof -i :5000  # Linux/macOS
netstat -ano | findstr :5000  # Windows

# 杀死进程
kill -9 <PID>
```

**问题2：数据库锁定**
```bash
# 检查SQLite锁文件
ls -la data/indusopsai.db-*

# 如有锁定，重启服务
sudo systemctl restart indusopsai
```

**问题3：依赖缺失**
```bash
# 重新安装依赖
pip install -r requirements.txt --force-reinstall
```

**问题4：权限问题**
```bash
# 检查目录权限
chmod -R 755 data logs

# 检查文件所有者
chown -R www-data:www-data data logs
```

### 10.2 日志分析

```bash
# 查看错误日志
grep ERROR logs/indusopsai.log

# 查看最近的日志
tail -n 100 logs/indusopsai.log

# 统计错误数量
grep -c ERROR logs/indusopsai.log
```

## 11. 升级指南

### 11.1 升级步骤

1. **备份数据**
```bash
# 备份数据库和配置文件
cp data/indusopsai.db data/indusopsai_backup_$(date +%Y%m%d).db
cp .env .env.backup
```

2. **拉取新代码**
```bash
git pull origin main
```

3. **更新依赖**
```bash
pip install -r requirements.txt --upgrade
```

4. **运行迁移脚本**（如有）
```bash
python scripts/migrate.py
```

5. **重启服务**
```bash
sudo systemctl restart indusopsai
```

### 11.2 回滚步骤

```bash
# 恢复备份
cp backup/indusopsai_YYYYMMDD_HHMMSS.db data/indusopsai.db

# 恢复代码
git checkout <previous_version>

# 重启服务
sudo systemctl restart indusopsai
```

## 12. 安全建议

### 12.1 生产环境安全

1. **修改默认密钥**：必须修改JWT_SECRET_KEY
2. **使用HTTPS**：配置SSL证书
3. **防火墙配置**：只开放必要端口
4. **定期更新**：及时更新安全补丁
5. **访问控制**：限制管理接口访问

### 12.2 数据安全

1. **定期备份**：自动化备份脚本
2. **加密存储**：敏感数据加密
3. **访问审计**：记录访问日志
4. **权限最小化**：最小权限原则

## 13. 联系支持

如遇到问题，请：
1. 查看日志文件
2. 查阅文档
3. 提交Issue到GitHub
4. 联系技术支持团队



