"""
初始化数据库脚本
"""
from src.data_layer.storage import DataStorage
from src.utils.logger import get_logger

_logger = get_logger(__name__)


def main():
    """初始化数据库"""
    _logger.info("开始初始化数据库...")
    
    storage = DataStorage()
    _logger.info("数据库初始化完成")


if __name__ == "__main__":
    main()



