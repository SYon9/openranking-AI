#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
IndusOpsAI 一键部署脚本
自动化完成环境检查、依赖安装、配置初始化等步骤
"""
import os
import sys
import subprocess
import shutil
from pathlib import Path
from typing import Tuple, Optional

# 设置标准输出编码为 UTF-8
if sys.platform == "win32":
    # Windows 系统设置控制台编码
    try:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.buffer, "strict")
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.buffer, "strict")
        # 设置控制台代码页为 UTF-8
        os.system("chcp 65001 >nul 2>&1")
    except:
        pass

# 颜色输出（Windows 和 Unix 都支持）
class Colors:
    if sys.platform == "win32":
        # Windows 使用简单的标记
        GREEN = ''
        YELLOW = ''
        RED = ''
        BLUE = ''
        RESET = ''
        BOLD = ''
    else:
        GREEN = '\033[92m'
        YELLOW = '\033[93m'
        RED = '\033[91m'
        BLUE = '\033[94m'
        RESET = '\033[0m'
        BOLD = '\033[1m'

def print_step(message: str):
    """打印步骤信息"""
    if sys.platform == "win32":
        print(f"[步骤] {message}")
    else:
        print(f"{Colors.BLUE}{Colors.BOLD}>>> {message}{Colors.RESET}")

def print_success(message: str):
    """打印成功信息"""
    if sys.platform == "win32":
        print(f"[成功] {message}")
    else:
        print(f"{Colors.GREEN}✓ {message}{Colors.RESET}")

def print_warning(message: str):
    """打印警告信息"""
    if sys.platform == "win32":
        print(f"[警告] {message}")
    else:
        print(f"{Colors.YELLOW}⚠ {message}{Colors.RESET}")

def print_error(message: str):
    """打印错误信息"""
    if sys.platform == "win32":
        print(f"[错误] {message}")
    else:
        print(f"{Colors.RED}✗ {message}{Colors.RESET}")

def run_command(cmd: list, check: bool = True, cwd: Optional[Path] = None) -> Tuple[bool, str]:
    """运行命令并返回结果"""
    try:
        # 设置编码环境变量
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        if sys.platform == "win32":
            # Windows 上强制使用 UTF-8
            env["PYTHONUTF8"] = "1"
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=check,
            cwd=cwd,
            env=env
        )
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr if e.stderr else str(e)
        return False, error_msg
    except FileNotFoundError:
        return False, "命令未找到"

def check_python_version() -> bool:
    """检查 Python 版本"""
    print_step("检查 Python 版本...")
    version = sys.version_info
    if version.major == 3 and version.minor >= 9:
        print_success(f"Python 版本: {version.major}.{version.minor}.{version.micro}")
        return True
    else:
        print_error(f"Python 版本 {version.major}.{version.minor}.{version.micro} 不符合要求（需要 3.9+）")
        return False

def check_pip() -> bool:
    """检查 pip 是否可用"""
    print_step("检查 pip...")
    success, _ = run_command([sys.executable, "-m", "pip", "--version"], check=False)
    if success:
        print_success("pip 可用")
        return True
    else:
        print_error("pip 不可用，请先安装 pip")
        return False

def upgrade_pip() -> bool:
    """升级 pip"""
    print_step("升级 pip、setuptools 和 wheel...")
    success, output = run_command([
        sys.executable, "-m", "pip", "install", "--upgrade", 
        "pip", "setuptools", "wheel"
    ])
    if success:
        print_success("pip 升级完成")
        return True
    else:
        print_warning(f"pip 升级失败: {output}")
        return False

def create_venv(venv_path: Path) -> bool:
    """创建虚拟环境"""
    print_step("创建虚拟环境...")
    if venv_path.exists():
        print_warning(f"虚拟环境已存在: {venv_path}")
        response = input("是否删除并重新创建？(y/N): ").strip().lower()
        if response == 'y':
            shutil.rmtree(venv_path)
        else:
            print_success("使用现有虚拟环境")
            return True
    
    success, output = run_command([sys.executable, "-m", "venv", str(venv_path)])
    if success:
        print_success(f"虚拟环境创建成功: {venv_path}")
        return True
    else:
        print_error(f"虚拟环境创建失败: {output}")
        return False

def get_pip_command(venv_path: Optional[Path] = None) -> list:
    """获取 pip 命令（考虑虚拟环境）"""
    if venv_path and venv_path.exists():
        if sys.platform == "win32":
            pip = venv_path / "Scripts" / "pip.exe"
        else:
            pip = venv_path / "bin" / "pip"
        if pip.exists():
            return [str(pip)]
    return [sys.executable, "-m", "pip"]

def install_requirements(venv_path: Optional[Path] = None) -> bool:
    """安装依赖"""
    print_step("安装项目依赖...")
    pip_cmd = get_pip_command(venv_path)
    
    # 先安装核心依赖
    success, output = run_command(
        pip_cmd + ["install", "-r", "requirements.txt"],
        cwd=Path.cwd()
    )
    if not success:
        print_error(f"依赖安装失败: {output}")
        return False
    
    print_success("核心依赖安装完成")
    
    # 询问是否安装开发依赖
    response = input("是否安装开发依赖？(y/N): ").strip().lower()
    if response == 'y':
        print_step("安装开发依赖...")
        success, output = run_command(
            pip_cmd + ["install", "-r", "requirements-dev.txt"],
            cwd=Path.cwd()
        )
        if success:
            print_success("开发依赖安装完成")
        else:
            print_warning(f"开发依赖安装失败: {output}")
    
    return True

def setup_env_file() -> bool:
    """设置环境变量文件"""
    print_step("配置环境变量...")
    env_file = Path(".env")
    env_example = Path(".env.example")
    
    if env_file.exists():
        print_warning(".env 文件已存在")
        response = input("是否覆盖现有 .env 文件？(y/N): ").strip().lower()
        if response != 'y':
            print_success("使用现有 .env 文件")
            return True
    
    if env_example.exists():
        shutil.copy(env_example, env_file)
        print_success(".env 文件已创建（基于 .env.example）")
        print_warning("请编辑 .env 文件配置相关参数（如 JWT_SECRET_KEY 等）")
    else:
        # 创建基本的 .env 文件
        env_content = """# IndusOpsAI 环境变量配置
# 生产环境请修改 JWT_SECRET_KEY
JWT_SECRET_KEY=indusopsai-secret-key-change-in-production
JWT_ACCESS_TOKEN_EXPIRES=3600
LOG_LEVEL=INFO
"""
        env_file.write_text(env_content, encoding="utf-8")
        print_success(".env 文件已创建（基本配置）")
        print_warning("请编辑 .env 文件配置相关参数")
    
    return True

def init_database() -> bool:
    """初始化数据库"""
    print_step("初始化数据库...")
    
    # 确定 Python 命令
    python_cmd = [sys.executable]
    if Path("venv").exists():
        if sys.platform == "win32":
            python_cmd = [str(Path("venv") / "Scripts" / "python.exe")]
        else:
            python_cmd = [str(Path("venv") / "bin" / "python")]
    
    success, output = run_command(
        python_cmd + ["scripts/init_db.py"],
        cwd=Path.cwd()
    )
    if success:
        print_success("数据库初始化完成")
        return True
    else:
        print_warning(f"数据库初始化失败: {output}")
        print_warning("可以稍后手动运行: python scripts/init_db.py")
        return False

def verify_deployment() -> bool:
    """验证部署"""
    print_step("验证部署...")
    
    # 检查关键文件
    required_files = [
        "requirements.txt",
        "src/api/app.py",
        "src/config.py",
    ]
    
    missing_files = []
    for file in required_files:
        if not Path(file).exists():
            missing_files.append(file)
    
    if missing_files:
        print_error(f"缺少必需文件: {', '.join(missing_files)}")
        return False
    
    # 检查依赖
    python_cmd = [sys.executable]
    if Path("venv").exists():
        if sys.platform == "win32":
            python_cmd = [str(Path("venv") / "Scripts" / "python.exe")]
        else:
            python_cmd = [str(Path("venv") / "bin" / "python")]
    
    success, _ = run_command(
        python_cmd + ["scripts/check_dependencies.py"],
        check=False,
        cwd=Path.cwd()
    )
    
    if success:
        print_success("部署验证通过")
    else:
        print_warning("部分依赖可能未正确安装，请检查")
    
    return True

def print_next_steps():
    """打印后续步骤"""
    print("\n" + "="*60)
    if sys.platform == "win32":
        print("[成功] 部署完成！")
    else:
        print(f"{Colors.BOLD}{Colors.GREEN}部署完成！{Colors.RESET}")
    print("="*60)
    print("\n后续步骤：")
    print("1. 编辑 .env 文件配置相关参数（特别是 JWT_SECRET_KEY）")
    print("2. 启动服务：")
    print("   - 开发环境: python run.py")
    if sys.platform == "win32":
        print("   - 生产环境: python scripts\\start_prod.py")
        print("   - 或使用: start_prod.bat")
    else:
        print("   - 生产环境: gunicorn -c gunicorn.conf.py src.api.app:create_app")
    print("3. 访问服务: http://localhost:5000")
    print("4. 健康检查: http://localhost:5000/health")
    print("\n更多信息请查看 README.md 和 DEPENDENCIES.md")
    print("="*60)

def main():
    """主函数"""
    print("="*60)
    if sys.platform == "win32":
        print("IndusOpsAI 一键部署脚本")
    else:
        print(f"{Colors.BOLD}IndusOpsAI 一键部署脚本{Colors.RESET}")
    print("="*60)
    print()
    
    # 检查是否在项目根目录
    if not Path("requirements.txt").exists():
        print_error("请在项目根目录运行此脚本")
        sys.exit(1)
    
    # 1. 检查 Python 版本
    if not check_python_version():
        sys.exit(1)
    
    # 2. 检查 pip
    if not check_pip():
        sys.exit(1)
    
    # 3. 升级 pip
    upgrade_pip()
    
    # 4. 创建虚拟环境
    venv_path = Path("venv")
    use_venv = input("是否使用虚拟环境？(Y/n): ").strip().lower()
    if use_venv != 'n':
        if not create_venv(venv_path):
            print_warning("虚拟环境创建失败，将使用系统 Python")
            venv_path = None
    else:
        venv_path = None
        print_warning("未使用虚拟环境，将直接安装到系统 Python")
    
    # 5. 安装依赖
    if not install_requirements(venv_path):
        print_error("依赖安装失败，请检查错误信息")
        sys.exit(1)
    
    # 6. 设置环境变量
    setup_env_file()
    
    # 7. 初始化数据库
    init_database()
    
    # 8. 验证部署
    verify_deployment()
    
    # 9. 打印后续步骤
    print_next_steps()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n部署已取消")
        sys.exit(1)
    except Exception as e:
        print_error(f"部署过程中发生错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

