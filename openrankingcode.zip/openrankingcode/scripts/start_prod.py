# -*- coding: utf-8 -*-
"""
Production server startup script
Automatically selects the appropriate WSGI server based on the platform
"""
import sys
import os
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

def start_server():
    """Start production server"""
    from src.api.app import create_app
    
    app = create_app()
    
    if sys.platform == "win32":
        # Windows: Use waitress
        try:
            from waitress import serve
            print("=" * 60)
            print("Starting production server with Waitress (Windows)")
            print("=" * 60)
            print("Server will be available at: http://0.0.0.0:5000")
            print("Press Ctrl+C to stop the server")
            print("=" * 60)
            
            # Get configuration from environment or use defaults
            host = os.getenv("HOST", "0.0.0.0")
            port = int(os.getenv("PORT", 5000))
            threads = int(os.getenv("WAITRESS_THREADS", 4))
            
            serve(app, host=host, port=port, threads=threads)
        except ImportError:
            print("ERROR: waitress is not installed")
            print("Please install it with: pip install waitress")
            print("\nFalling back to development server...")
            app.run(host="0.0.0.0", port=5000, debug=False)
    else:
        # Linux/macOS: Use gunicorn
        try:
            import gunicorn.app.wsgiapp as wsgi
            
            print("=" * 60)
            print("Starting production server with Gunicorn (Linux/macOS)")
            print("=" * 60)
            print("Server will be available at: http://0.0.0.0:5000")
            print("Press Ctrl+C to stop the server")
            print("=" * 60)
            
            # Use gunicorn configuration file if it exists
            config_file = project_root / "gunicorn.conf.py"
            if config_file.exists():
                sys.argv = [
                    "gunicorn",
                    "-c", str(config_file),
                    "src.api.app:create_app"
                ]
            else:
                sys.argv = [
                    "gunicorn",
                    "-w", "4",
                    "-b", "0.0.0.0:5000",
                    "src.api.app:create_app"
                ]
            
            wsgi.run()
        except ImportError:
            print("ERROR: gunicorn is not installed")
            print("Please install it with: pip install gunicorn")
            print("\nFalling back to development server...")
            app.run(host="0.0.0.0", port=5000, debug=False)

if __name__ == "__main__":
    try:
        start_server()
    except KeyboardInterrupt:
        print("\n\nServer stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"\nERROR: Failed to start server: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

