#!/usr/bin/env python3
"""
依赖检查脚本
用于验证所有依赖是否正确安装且版本兼容
"""
import sys
import importlib
import pkg_resources
from typing import Dict, List, Tuple

# 必需的核心依赖
REQUIRED_PACKAGES = {
    'pandas': '>=2.0.0',
    'numpy': '>=1.24.0',
    'scipy': '>=1.10.0',
    'scikit-learn': '>=1.3.0',
    'flask': '>=3.0.0',
    'flask-cors': '>=4.0.0',
    'flask-jwt-extended': '>=4.6.0',
    'flask-restful': '>=0.3.10',
    'werkzeug': '>=3.0.0',
    'redis': '>=5.0.0',
    # 'apache-iotdb': '>=1.0.0',  # Optional - IoTDB support
    'jieba': '>=0.42.0',
    'requests': '>=2.31.0',
    'python-dotenv': '>=1.0.0',
    'loguru': '>=0.7.0',
    'tqdm': '>=4.66.0',
    'cryptography': '>=41.0.0',
    'pyjwt': '>=2.8.0',
}

# 可选依赖（如果安装则检查版本）
OPTIONAL_PACKAGES = {
    'torch': '>=2.0.0',
    'torch-geometric': '>=2.4.0',
}


def check_package(package_name: str, version_spec: str) -> Tuple[bool, str, str]:
    """
    检查包是否安装且版本是否符合要求
    
    Returns:
        (is_installed, installed_version, status_message)
    """
    try:
        dist = pkg_resources.get_distribution(package_name)
        installed_version = dist.version
        
        # 检查版本是否符合要求
        if pkg_resources.require(f"{package_name}{version_spec}"):
            return True, installed_version, "✓"
        else:
            return True, installed_version, f"⚠ 版本 {installed_version} 可能不符合要求 {version_spec}"
    except pkg_resources.DistributionNotFound:
        return False, "未安装", "✗"
    except Exception as e:
        return False, "错误", f"✗ {str(e)}"


def check_python_version():
    """检查 Python 版本"""
    version = sys.version_info
    if version.major == 3 and version.minor >= 9:
        print(f"✓ Python 版本: {version.major}.{version.minor}.{version.micro}")
        return True
    else:
        print(f"✗ Python 版本: {version.major}.{version.minor}.{version.micro} (需要 3.9+)")
        return False


def main():
    """主函数"""
    print("=" * 60)
    print("IndusOpsAI 依赖检查工具")
    print("=" * 60)
    print()
    
    # 检查 Python 版本
    print("1. 检查 Python 版本...")
    python_ok = check_python_version()
    print()
    
    if not python_ok:
        print("❌ Python 版本不符合要求，请升级到 Python 3.9+")
        sys.exit(1)
    
    # 检查核心依赖
    print("2. 检查核心依赖...")
    missing_packages = []
    version_issues = []
    
    for package, version_spec in REQUIRED_PACKAGES.items():
        is_installed, installed_version, status = check_package(package, version_spec)
        print(f"  {status} {package:20s} {installed_version:15s} (要求: {version_spec})")
        
        if not is_installed:
            missing_packages.append(package)
        elif "⚠" in status:
            version_issues.append((package, installed_version, version_spec))
    
    print()
    
    # 检查可选依赖
    print("3. 检查可选依赖...")
    for package, version_spec in OPTIONAL_PACKAGES.items():
        is_installed, installed_version, status = check_package(package, version_spec)
        if is_installed:
            print(f"  {status} {package:20s} {installed_version:15s} (要求: {version_spec})")
        else:
            print(f"  - {package:20s} 未安装 (可选)")
    
    print()
    
    # 总结
    print("=" * 60)
    print("检查结果总结")
    print("=" * 60)
    
    if missing_packages:
        print(f"❌ 缺少 {len(missing_packages)} 个必需依赖:")
        for pkg in missing_packages:
            print(f"   - {pkg}")
        print()
        print("请运行以下命令安装:")
        print(f"  pip install {' '.join(missing_packages)}")
        print()
        sys.exit(1)
    
    if version_issues:
        print(f"⚠  {len(version_issues)} 个依赖版本可能不符合要求:")
        for pkg, installed, required in version_issues:
            print(f"   - {pkg}: 已安装 {installed}, 要求 {required}")
        print()
        print("建议运行以下命令更新:")
        print("  pip install --upgrade -r requirements.txt")
        print()
    
    if not missing_packages and not version_issues:
        print("✓ 所有核心依赖已正确安装！")
        print()
        print("可选依赖:")
        optional_missing = [pkg for pkg in OPTIONAL_PACKAGES.keys() 
                          if not check_package(pkg, OPTIONAL_PACKAGES[pkg])[0]]
        if optional_missing:
            print(f"  - {', '.join(optional_missing)} 未安装（可选）")
        else:
            print("  - 所有可选依赖已安装")
    
    print()
    sys.exit(0)


if __name__ == "__main__":
    main()


