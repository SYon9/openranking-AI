# IndusOpsAI：工业物联网设备运维智能赋能平台

## 项目简介

IndusOpsAI是一个基于数据驱动的开源生态全链路价值赋能平台，聚焦工业物联网设备运维场景，通过融合IoTDB、OpenDigger、DataEase、MaxKB等开源工具，构建"数据采集-治理-分析-可视化-交互赋能"的完整技术闭环。

## 核心特性

### 1. 时序驱动的工业设备健康度评估与故障预警
- 基于"5+X"动态加权健康度评估模型
- LSTM时序预测实现风险预警
- 多维度健康度评分卡与优化建议

### 2. 开发者贡献路径智能规划
- 基于OpenRank的三维路径规划模型
- 技能标签自动提取与匹配
- 个性化成长路径推荐

### 3. 开源协作网络精准匹配
- 基于GNN的协作网络图谱构建
- 项目-开发者-机构三方协同匹配
- 智能协作伙伴推荐

### 4. 时序数据可视化与智能问答联动
- 自然语言交互到数据查询的语义映射
- 问答结果与可视化图表自动关联
- RAG技术驱动的知识库问答

## 项目结构

```
IndusOpsAI/
├── src/                  # 源代码
│   ├── api/              # API接口和前端界面
│   ├── core/             # 核心算法模块
│   ├── data_layer/       # 数据层
│   ├── integrations/     # 工具集成
│   ├── services/         # 服务层
│   └── utils/            # 工具类
├── scripts/              # 部署和工具脚本
├── docs/                 # 详细文档
├── requirements.txt     # 核心依赖
└── README.md            # 项目说明
```

📊 **逻辑思维图**：查看 [逻辑思维图文档](LOGIC_DIAGRAM.md) 了解系统整体架构和流程

## 🌐 前端界面

项目提供了美观的Web前端界面，支持所有API功能的可视化操作。

### 访问前端界面

1. 启动服务后，在浏览器中打开：
   ```
   http://localhost:5000
   ```

2. 输入服务地址并保存配置

3. 使用顶部标签页切换不同功能模块：
   - 📊 **概览** - 系统状态和健康检查
   - 📁 **项目管理** - 项目查询、健康度评估
   - 👥 **开发者** - 开发者档案、成长路径
   - 🤝 **智能匹配** - 项目-贡献者匹配、协作伙伴推荐
   - 💬 **智能问答** - 自然语言查询
   - 🧪 **测试用例** - API功能测试

📖 详细使用说明请查看 [使用指南](USAGE_GUIDE.md)

🧪 测试用例请查看 [测试用例文档](TEST_CASES.md)

## 快速开始

### 🚀 一键部署（推荐）

最快的方式部署项目，只需一条命令：

**Linux/macOS:**
```bash
git clone https://github.com/your-org/IndusOpsAI.git && cd IndusOpsAI && bash deploy.sh
```

**Windows:**
```bash
git clone https://github.com/your-org/IndusOpsAI.git && cd IndusOpsAI && deploy.bat
```

**跨平台（Python 脚本）:**
```bash
git clone https://github.com/your-org/IndusOpsAI.git && cd IndusOpsAI && python scripts/deploy.py
```

**如果遇到编码问题（Windows），请查看 [部署文档](docs/DEPLOYMENT.md) 中的故障排除部分**

一键部署脚本会自动完成：环境检查、创建虚拟环境、安装依赖、配置初始化、数据库初始化等所有步骤。

📖 详细使用说明请查看 [使用指南](USAGE_GUIDE.md)

### 环境要求
- **Python 3.9+** (推荐 3.9, 3.10, 3.11 或 3.12)
- **pip 23.0+** (推荐使用最新版本)
- Redis 6+ (可选，用于缓存)
- IoTDB 1.0+ (可选，用于时序数据存储，需要先安装 thrift>=0.13)

### 一键部署（推荐）

我们提供了一键部署脚本，可以自动完成所有安装步骤：

**Linux/macOS:**
```bash
git clone https://github.com/your-org/IndusOpsAI.git
cd IndusOpsAI
bash deploy.sh
```

**Windows:**
```bash
git clone https://github.com/your-org/IndusOpsAI.git
cd IndusOpsAI
deploy.bat
```

**跨平台（Python 脚本）:**
```bash
git clone https://github.com/your-org/IndusOpsAI.git
cd IndusOpsAI
python scripts/deploy.py
```

一键部署脚本会自动完成：
- ✅ 检查 Python 版本
- ✅ 创建虚拟环境
- ✅ 安装所有依赖
- ✅ 配置环境变量
- ✅ 初始化数据库
- ✅ 验证部署

### 手动安装步骤

如果需要手动安装，请按照以下步骤：

1. 克隆仓库
```bash
git clone https://github.com/your-org/IndusOpsAI.git
cd IndusOpsAI
```

2. 创建虚拟环境（强烈推荐）
```bash
# 创建虚拟环境
python -m venv venv

# 激活虚拟环境
# Linux/macOS:
source venv/bin/activate
# Windows:
venv\Scripts\activate
```

3. 升级 pip 和安装工具（重要）
```bash
pip install --upgrade pip setuptools wheel
```

4. 安装Python依赖
```bash
# 安装核心依赖（必需）
pip install -r requirements.txt

# 如果需要开发工具（可选）
pip install -r requirements-dev.txt

# 如果需要可选功能（可选）
pip install -r requirements-optional.txt
```

5. 验证依赖安装（推荐）
```bash
python scripts/check_dependencies.py
```

**注意**：如果安装 PyTorch 时遇到问题，请根据您的系统访问 [PyTorch 官网](https://pytorch.org/get-started/locally/) 获取正确的安装命令。

5. 验证依赖安装（推荐）
```bash
python scripts/check_dependencies.py
```

6. 配置环境变量（可选）
```bash
# 创建 .env 文件并配置环境变量（可选，系统有默认值）
# 主要配置项：
# JWT_SECRET_KEY=your-secret-key-here  # 生产环境必须修改
# REDIS_HOST=localhost
# REDIS_PORT=6379
# IOTDB_HOST=localhost
# IOTDB_PORT=6667
# 更多配置请参考 src/config.py
```

7. 初始化数据库
```bash
python scripts/init_db.py
```

8. 验证部署（推荐）
```bash
# 运行依赖检查脚本，验证所有依赖是否正确安装
python scripts/check_dependencies.py
```

10. 启动服务
```bash
# 开发环境：使用启动脚本
python run.py

# 开发环境：直接运行
python src/api/app.py

# 生产环境
# Linux/macOS: 使用 Gunicorn
gunicorn -c gunicorn.conf.py "src.api.app:create_app"

# Windows: 使用 Waitress（Gunicorn 不支持 Windows）
python scripts\start_prod.py
# 或使用批处理脚本
start_prod.bat

# 服务将在 http://localhost:5000 启动
```

### 依赖安装问题排查

如果遇到依赖安装问题，请尝试以下解决方案：

1. **确保 Python 版本正确**
```bash
python --version  # 应该显示 3.9 或更高版本
```

2. **升级 pip 和安装工具**
```bash
pip install --upgrade pip setuptools wheel
```

3. **使用国内镜像源加速安装（可选）**
```bash
# 使用清华镜像
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# 或使用阿里云镜像
pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/
```

4. **PyTorch 安装问题**
   - CPU 版本：`pip install torch torch-geometric --index-url https://download.pytorch.org/whl/cpu`
   - GPU 版本：访问 [PyTorch 官网](https://pytorch.org/get-started/locally/) 获取对应命令

5. **编译依赖问题（Linux）**
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install -y gcc g++ python3-dev

# CentOS/RHEL
sudo yum install -y gcc gcc-c++ python3-devel
```

6. **Windows 编译问题**
   - 安装 [Microsoft C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)
   - 或使用预编译的 wheel 包（推荐）

7. **清理并重新安装**
```bash
# 清理 pip 缓存
pip cache purge

# 删除虚拟环境并重新创建
rm -rf venv  # Linux/macOS
rmdir /s venv  # Windows
python -m venv venv
source venv/bin/activate  # 或 venv\Scripts\activate (Windows)
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
```

## 核心模块说明

### 数据层 (data_layer)
- `collector.py`: 数据采集模块 - 从OpenDigger、GitHub等数据源采集开源项目数据
- `processor.py`: 数据治理模块 - 数据清洗、脱敏、标准化、特征提取
- `storage.py`: 数据存储模块 - SQLite、Redis、IoTDB多存储支持

### 核心算法 (core)
- `health_assessment.py`: 健康度评估模型 - 5+X动态加权评估，熵权法权重计算
- `path_planning.py`: 贡献路径规划 - 技能-任务-成长三维路径规划
- `matching_engine.py`: GNN协作匹配引擎 - 基于图神经网络的协作匹配
- `forecast_model.py`: LSTM时序预测模型 - 健康度趋势预测与风险预警

### 工具集成 (integrations)
- `opendigger_client.py`: OpenDigger集成 - 开源数据采集与分析
- `iotdb_client.py`: IoTDB时序数据库集成 - 时序数据存储与查询
- `dataease_client.py`: DataEase可视化集成 - 可视化仪表板创建
- `maxkb_client.py`: MaxKB智能问答集成 - RAG知识库问答

### 服务层 (services)
- `project_service.py`: 项目服务 - 项目管理与健康度评估
- `developer_service.py`: 开发者服务 - 开发者档案与路径规划
- `matching_service.py`: 匹配服务 - 协作匹配
- `qa_service.py`: 问答服务 - 智能问答

### API层 (api)
- `app.py`: Flask应用入口
- `routes.py`: RESTful API路由定义

## 核心创新点

1. **时序驱动的健康度评估**: 基于5+X动态加权模型，结合熵权法和AHP，实现精准评估
2. **LSTM时序预测**: 预测项目健康度趋势，提前预警风险
3. **GNN协作匹配**: 基于图神经网络实现项目-开发者-机构三方精准匹配
4. **智能路径规划**: 为开发者提供个性化的开源贡献成长路径
5. **自然语言交互**: 集成MaxKB实现问答与可视化的智能联动

## 使用方式

### 🌐 方式一：Web前端界面（推荐）

1. 启动服务后，在浏览器中打开：`http://localhost:5000`
2. 输入服务地址并保存配置
3. 使用标签页切换不同功能模块
4. 所有操作都有可视化界面，无需编写代码

📖 详细使用说明请查看 [使用指南](USAGE_GUIDE.md)

### 💻 方式二：API调用

#### 获取项目健康度
```bash
curl http://localhost:5000/api/v1/projects/apache/iotdb/health
```

#### 规划开发者贡献路径
```bash
curl "http://localhost:5000/api/v1/developers/dev123/path?project_repo=apache/iotdb&target_openrank=100"
```

#### 智能问答
```bash
curl -X POST http://localhost:5000/api/v1/qa/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "Apache IoTDB的健康度如何？", "project_repo": "apache/iotdb"}'
```

更多API文档请查看 [docs/API.md](docs/API.md)

### 🧪 方式三：测试用例

使用前端界面的"测试用例"标签页，一键运行所有测试用例。

详细测试用例请查看 [测试用例文档](TEST_CASES.md)

## 项目结构

```
IndusOpsAI/
├── src/                    # 源代码
│   ├── api/               # API层
│   ├── core/              # 核心算法
│   ├── data_layer/        # 数据层
│   ├── integrations/      # 工具集成
│   ├── services/          # 服务层
│   └── utils/             # 工具函数
├── data/                  # 数据存储目录
├── docs/                  # 文档
├── scripts/               # 脚本
├── tests/                 # 测试
├── requirements.txt       # Python依赖
├── setup.py              # 安装配置
└── run.py                # 启动脚本
```

## 技术亮点

- ✅ 模块化设计，易于扩展和维护
- ✅ 完整的错误处理和日志系统
- ✅ RESTful API设计，支持多客户端
- ✅ 数据脱敏和安全性保护
- ✅ 支持增量数据更新
- ✅ 集成多个开源工具，形成完整闭环

## 🏆 项目亮点

### 技术创新
- ✅ **4个核心算法创新**：5+X健康度评估、LSTM预测、GNN匹配、三维路径规划
- ✅ **多工具集成**：IoTDB + OpenDigger + DataEase + MaxKB 完整技术闭环
- ✅ **多存储后端**：SQLite + Redis + IoTDB 性能优化架构

### 实用价值
- ✅ **解决实际问题**：项目评估、开发者成长、协作匹配、风险预警
- ✅ **应用场景广泛**：高校、企业、社区等多场景应用
- ✅ **用户友好**：Web界面、一键部署、完整文档

### 工程化水平
- ✅ **文档完善**：技术文档、使用指南、API文档、测试用例
- ✅ **部署便捷**：跨平台一键部署脚本
- ✅ **代码规范**：模块化设计、清晰结构

### 可展示性
- ✅ **前端界面**：美观的Web界面，支持所有功能
- ✅ **可视化**：丰富的图表展示
- ✅ **演示完整**：完整的演示流程和指南

📖 **详细亮点**：查看 [项目亮点总结](AWARD_HIGHLIGHTS.md) 和 [演示指南](DEMO_GUIDE.md)

## 开发计划

- [x] 前端界面开发（已完成 - 美观的Web界面）
- [x] 核心算法实现（已完成 - 4个核心算法）
- [x] 多工具集成（已完成 - IoTDB、OpenDigger、DataEase、MaxKB）
- [x] 文档完善（已完成 - 完整文档体系）
- [ ] 更多可视化组件
- [ ] 性能优化和缓存策略
- [ ] 单元测试和集成测试
- [ ] 容器化部署（Docker）
- [ ] CI/CD流水线

## 许可证

Apache 2.0

## 贡献指南

欢迎贡献！请查看 [CONTRIBUTING.md](CONTRIBUTING.md) 了解详细信息。

## 文档

### 核心文档（必读）

#### 🏆 获奖相关
- [项目亮点总结](AWARD_HIGHLIGHTS.md) - **⭐ 项目亮点、获奖优势、技术成果和性能指标**
- [演示指南](DEMO_GUIDE.md) - **⭐ 完整演示流程、评审要点和检查清单**

#### 📚 技术文档
- [创新点说明](INNOVATION.md) - **核心创新点和技术亮点详解**
- [逻辑思维图](LOGIC_DIAGRAM.md) - **系统逻辑架构和流程图（12个Mermaid图表）**
- [使用指南](USAGE_GUIDE.md) - **前端界面使用说明和API使用示例**
- [测试用例](TEST_CASES.md) - **完整的测试用例文档**

### 技术文档
- [架构文档](docs/ARCHITECTURE.md) - 系统架构设计说明
- [技术文档](docs/TECHNICAL.md) - 详细技术实现说明
- [部署文档](docs/DEPLOYMENT.md) - 完整部署指南（包含Windows部署说明和依赖管理）
- [API文档](docs/API.md) - API接口文档

### 其他
- [贡献指南](CONTRIBUTING.md) - 贡献代码指南

## 联系我们

- 项目主页: https://github.com/your-org/IndusOpsAI
- 问题反馈: https://github.com/your-org/IndusOpsAI/issues

