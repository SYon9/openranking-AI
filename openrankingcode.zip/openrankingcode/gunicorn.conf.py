"""
Gunicorn配置文件
用于生产环境部署
"""
import multiprocessing
import os

# 服务器配置
bind = os.getenv("GUNICORN_BIND", "0.0.0.0:5000")
workers = int(os.getenv("GUNICORN_WORKERS", multiprocessing.cpu_count() * 2 + 1))
worker_class = os.getenv("GUNICORN_WORKER_CLASS", "sync")
worker_connections = int(os.getenv("GUNICORN_WORKER_CONNECTIONS", 1000))
timeout = int(os.getenv("GUNICORN_TIMEOUT", 120))
keepalive = int(os.getenv("GUNICORN_KEEPALIVE", 5))

# 日志配置
accesslog = os.getenv("GUNICORN_ACCESS_LOG", "logs/access.log")
errorlog = os.getenv("GUNICORN_ERROR_LOG", "logs/error.log")
loglevel = os.getenv("GUNICORN_LOG_LEVEL", "info")
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# 性能配置
max_requests = int(os.getenv("GUNICORN_MAX_REQUESTS", 1000))
max_requests_jitter = int(os.getenv("GUNICORN_MAX_REQUESTS_JITTER", 100))
preload_app = os.getenv("GUNICORN_PRELOAD_APP", "False").lower() == "true"

# 进程名称
proc_name = "indusopsai"

# SSL配置（如需HTTPS）
# keyfile = "/path/to/keyfile"
# certfile = "/path/to/certfile"



