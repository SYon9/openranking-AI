"""
IndusOpsAI 安装脚本
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

def parse_requirements(filename):
    """解析 requirements.txt 文件，排除注释和空行"""
    requirements = []
    with open(filename, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            # 跳过空行、注释行和条件依赖标记
            if line and not line.startswith("#") and not line.startswith("-r"):
                # 移除行内注释
                if "#" in line:
                    line = line.split("#")[0].strip()
                if line:
                    requirements.append(line)
    return requirements

requirements = parse_requirements("requirements.txt")

setup(
    name="indusopsai",
    version="1.0.0",
    author="IndusOpsAI Team",
    description="工业物联网设备运维智能赋能平台",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-org/IndusOpsAI",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.9",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "indusopsai=src.api.app:create_app",
        ],
    },
)



