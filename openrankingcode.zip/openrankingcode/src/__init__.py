"""
IndusOpsAI: 工业物联网设备运维智能赋能平台
"""

__version__ = "1.0.0"
__author__ = "IndusOpsAI Team"



