"""
项目健康度评估模型
实现"5+X"动态加权健康度评估模型，采用熵权法结合AHP确定权重
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from scipy.stats import entropy
from sklearn.preprocessing import MinMaxScaler
import warnings
warnings.filterwarnings('ignore')

from src.utils.logger import get_logger

_logger = get_logger(__name__)


class HealthAssessmentModel:
    """项目健康度评估模型"""
    
    # 5个核心维度
    CORE_DIMENSIONS = {
        "code_activity": "代码活跃度",
        "issue_efficiency": "Issue解决效能",
        "contributor_ecology": "贡献者生态",
        "collaboration_quality": "社区协作质量",
        "compliance_security": "合规安全性"
    }
    
    def __init__(self, custom_dimensions: Optional[Dict[str, str]] = None):
        """
        初始化健康度评估模型
        
        Args:
            custom_dimensions: 自定义维度字典，格式 {"dimension_key": "dimension_name"}
        """
        self.custom_dimensions = custom_dimensions or {}
        self.weights = {}
        self.scaler = MinMaxScaler()
    
    def calculate_health_score(self, project_data: Dict, 
                              use_entropy_weight: bool = True) -> Dict:
        """
        计算项目健康度综合评分
        
        Args:
            project_data: 项目数据字典
            use_entropy_weight: 是否使用熵权法计算权重
        
        Returns:
            健康度评估结果字典
        """
        try:
            # 提取指标数据
            indicators = self._extract_indicators(project_data)
            
            # 标准化指标
            normalized_indicators = self._normalize_indicators(indicators)
            
            # 计算权重
            if use_entropy_weight:
                self.weights = self._calculate_entropy_weights(normalized_indicators)
            else:
                self.weights = self._get_default_weights()
            
            # 计算各维度得分
            dimension_scores = self._calculate_dimension_scores(
                normalized_indicators, self.weights
            )
            
            # 计算综合得分
            overall_score = sum(
                score * self.weights.get(dim, 0)
                for dim, score in dimension_scores.items()
            )
            
            # 识别风险
            risks = self._identify_risks(indicators, dimension_scores)
            
            # 生成优化建议
            suggestions = self._generate_suggestions(
                indicators, dimension_scores, risks
            )
            
            result = {
                "overall_score": round(overall_score, 2),
                "dimension_scores": {
                    k: round(v, 2) for k, v in dimension_scores.items()
                },
                "weights": {
                    k: round(v, 4) for k, v in self.weights.items()
                },
                "indicators": indicators,
                "risks": risks,
                "suggestions": suggestions,
                "assessed_at": datetime.now().isoformat(),
                "grade": self._get_grade(overall_score)
            }
            
            _logger.info(f"健康度评估完成，综合得分: {overall_score:.2f}")
            return result
            
        except Exception as e:
            _logger.error(f"健康度评估失败: {str(e)}")
            raise
    
    def _extract_indicators(self, project_data: Dict) -> Dict:
        """提取各维度指标"""
        metrics = project_data.get("metrics", {})
        contributors = project_data.get("contributors", [])
        
        indicators = {}
        
        # 1. 代码活跃度
        activity = metrics.get("activity", {})
        indicators["code_activity"] = {
            "commit_frequency": activity.get("commit_frequency", 0),
            "commit_count": activity.get("commit_count", 0),
            "active_days": activity.get("active_days", 0),
            "active_ratio": activity.get("active_ratio", 0)
        }
        
        # 2. Issue解决效能
        issue_pr = metrics.get("issue_pr", {})
        indicators["issue_efficiency"] = {
            "resolution_rate": issue_pr.get("issue_resolution_rate", 0),
            "avg_resolution_time": issue_pr.get("avg_resolution_time", 0),
            "backlog_ratio": issue_pr.get("issue_backlog_ratio", 0),
            "pr_merge_rate": issue_pr.get("pr_merge_rate", 0)
        }
        
        # 3. 贡献者生态
        indicators["contributor_ecology"] = {
            "total_contributors": len(contributors),
            "core_contributors": len([c for c in contributors if c.get("contributions", 0) > 100]),
            "new_contributors": len([c for c in contributors if c.get("first_contribution_at")]),
            "avg_openrank": np.mean([c.get("openrank", 0) for c in contributors]) if contributors else 0
        }
        
        # 4. 社区协作质量（基于OpenRank和贡献者多样性）
        openrank = metrics.get("openrank", {})
        indicators["collaboration_quality"] = {
            "openrank_score": openrank.get("current_score", 0),
            "openrank_trend": 1.0 if openrank.get("trend") == "increasing" else 0.5,
            "contributor_diversity": len(set([c.get("login") for c in contributors if c.get("login")])),
            "skill_diversity": len(set(
                tag for c in contributors 
                for tag in c.get("skill_tags", [])
            ))
        }
        
        # 5. 合规安全性（简化处理，实际应从项目元数据提取）
        indicators["compliance_security"] = {
            "license_score": 1.0,  # 假设有许可证
            "vulnerability_score": 0.8,  # 简化处理
            "dependency_score": 0.9  # 简化处理
        }
        
        # 自定义维度
        for dim_key, dim_name in self.custom_dimensions.items():
            indicators[dim_key] = project_data.get("custom_indicators", {}).get(dim_key, {})
        
        return indicators
    
    def _normalize_indicators(self, indicators: Dict) -> Dict:
        """标准化指标数据（归一化到[0,1]）"""
        normalized = {}
        
        for dimension, dim_indicators in indicators.items():
            normalized[dimension] = {}
            
            for key, value in dim_indicators.items():
                if isinstance(value, (int, float)):
                    # Min-Max归一化（简化版，实际应基于历史数据计算）
                    # 这里使用经验阈值
                    if "rate" in key or "ratio" in key:
                        # 比率类指标直接使用
                        normalized[dimension][key] = max(0, min(1, value))
                    elif "score" in key:
                        # 分数类指标归一化（假设满分100）
                        normalized[dimension][key] = max(0, min(1, value / 100))
                    elif "count" in key or "frequency" in key or "days" in key:
                        # 计数类指标归一化（假设上限1000）
                        normalized[dimension][key] = max(0, min(1, value / 1000))
                    else:
                        normalized[dimension][key] = max(0, min(1, value))
                else:
                    normalized[dimension][key] = value
        
        return normalized
    
    def _calculate_entropy_weights(self, normalized_indicators: Dict) -> Dict:
        """
        使用熵权法计算权重
        
        熵权法原理：
        1. 信息熵越大，指标区分度越低，权重越小
        2. 信息熵越小，指标区分度越高，权重越大
        """
        try:
            # 构建指标矩阵
            dimension_list = list(normalized_indicators.keys())
            indicator_matrix = []
            
            for dim in dimension_list:
                # 计算维度综合得分（各指标平均值）
                dim_indicators = normalized_indicators[dim]
                numeric_values = [
                    v for v in dim_indicators.values() 
                    if isinstance(v, (int, float))
                ]
                if numeric_values:
                    dim_score = np.mean(numeric_values)
                else:
                    dim_score = 0.5  # 默认值
                indicator_matrix.append(dim_score)
            
            indicator_matrix = np.array(indicator_matrix)
            
            # 避免对数运算中的0值
            indicator_matrix = indicator_matrix + 1e-10
            
            # 归一化（每列归一化）
            indicator_matrix = indicator_matrix / (indicator_matrix.sum() + 1e-10)
            
            # 计算熵值
            entropies = []
            for i in range(len(indicator_matrix)):
                # 使用信息熵公式：H = -Σ(p * log(p))
                p = indicator_matrix[i]
                if p > 0:
                    entropy_val = -p * np.log(p)
                else:
                    entropy_val = 0
                entropies.append(entropy_val)
            
            entropies = np.array(entropies)
            
            # 计算权重：w = (1 - H) / Σ(1 - H)
            diversity = 1 - entropies  # 多样性系数
            weights = diversity / (diversity.sum() + 1e-10)
            
            # 转换为字典
            weight_dict = dict(zip(dimension_list, weights))
            
            # 归一化权重（确保和为1）
            total_weight = sum(weight_dict.values())
            if total_weight > 0:
                weight_dict = {k: v / total_weight for k, v in weight_dict.items()}
            
            return weight_dict
            
        except Exception as e:
            _logger.warning(f"熵权法计算失败，使用默认权重: {str(e)}")
            return self._get_default_weights()
    
    def _get_default_weights(self) -> Dict:
        """获取默认权重（AHP方法的简化版本）"""
        default_weights = {
            "code_activity": 0.20,
            "issue_efficiency": 0.20,
            "contributor_ecology": 0.20,
            "collaboration_quality": 0.25,
            "compliance_security": 0.15
        }
        
        # 添加自定义维度权重（平均分配剩余权重）
        if self.custom_dimensions:
            remaining_weight = 1.0 - sum(default_weights.values())
            per_custom_weight = remaining_weight / len(self.custom_dimensions)
            for dim_key in self.custom_dimensions:
                default_weights[dim_key] = per_custom_weight
        
        # 归一化
        total = sum(default_weights.values())
        if total > 0:
            default_weights = {k: v / total for k, v in default_weights.items()}
        
        return default_weights
    
    def _calculate_dimension_scores(self, normalized_indicators: Dict,
                                   weights: Dict) -> Dict:
        """计算各维度得分"""
        dimension_scores = {}
        
        for dimension, dim_indicators in normalized_indicators.items():
            # 计算维度内各指标的平均值（加权平均）
            numeric_values = [
                v for v in dim_indicators.values() 
                if isinstance(v, (int, float))
            ]
            
            if numeric_values:
                # 使用均值作为维度得分
                dimension_scores[dimension] = np.mean(numeric_values)
            else:
                dimension_scores[dimension] = 0.5
        
        return dimension_scores
    
    def _identify_risks(self, indicators: Dict, 
                       dimension_scores: Dict) -> List[Dict]:
        """识别风险点"""
        risks = []
        
        # 代码活跃度风险
        if dimension_scores.get("code_activity", 0) < 0.3:
            risks.append({
                "type": "活跃度下滑",
                "level": "high",
                "dimension": "code_activity",
                "description": "项目代码活跃度较低，可能存在维护风险"
            })
        
        # Issue积压风险
        backlog_ratio = indicators.get("issue_efficiency", {}).get("backlog_ratio", 0)
        if backlog_ratio > 0.3:
            risks.append({
                "type": "Issue积压",
                "level": "medium",
                "dimension": "issue_efficiency",
                "description": f"Issue积压率 {backlog_ratio:.1%}，需要及时处理"
            })
        
        # 贡献者流失风险
        if dimension_scores.get("contributor_ecology", 0) < 0.4:
            risks.append({
                "type": "贡献者流失",
                "level": "high",
                "dimension": "contributor_ecology",
                "description": "贡献者生态不健康，可能面临维护者短缺"
            })
        
        # 合规风险
        if dimension_scores.get("compliance_security", 0) < 0.6:
            risks.append({
                "type": "合规风险",
                "level": "medium",
                "dimension": "compliance_security",
                "description": "项目在合规性方面存在风险，建议加强审查"
            })
        
        return risks
    
    def _generate_suggestions(self, indicators: Dict, 
                             dimension_scores: Dict, 
                             risks: List[Dict]) -> List[Dict]:
        """生成优化建议"""
        suggestions = []
        
        for risk in risks:
            dim = risk["dimension"]
            
            if dim == "code_activity":
                suggestions.append({
                    "action": "增加代码提交频率",
                    "priority": "high" if risk["level"] == "high" else "medium",
                    "dimension": dim,
                    "target": "将月度提交次数提升至50+"
                })
            
            elif dim == "issue_efficiency":
                suggestions.append({
                    "action": "优化Issue处理流程",
                    "priority": "medium",
                    "dimension": dim,
                    "target": "设置Issue响应SLA，确保72小时内响应"
                })
            
            elif dim == "contributor_ecology":
                suggestions.append({
                    "action": "扩大贡献者群体",
                    "priority": "high",
                    "dimension": dim,
                    "target": "通过good first issue、文档改进等方式吸引新贡献者"
                })
        
        return suggestions
    
    def _get_grade(self, score: float) -> str:
        """根据得分获取等级"""
        if score >= 0.9:
            return "优秀"
        elif score >= 0.75:
            return "良好"
        elif score >= 0.6:
            return "中等"
        elif score >= 0.4:
            return "较差"
        else:
            return "差"



