"""
开发者贡献路径规划模块
实现"技能-任务-成长"三维路径规划模型
"""
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta

from src.utils.logger import get_logger

_logger = get_logger(__name__)


class PathPlanningModel:
    """开发者贡献路径规划模型"""
    
    # 开发者层级定义
    DEVELOPER_LEVELS = {
        "beginner": {
            "name": "新手开发者",
            "openrank_min": 0,
            "openrank_max": 10,
            "tasks": ["good_first_issue", "documentation", "testing"]
        },
        "intermediate": {
            "name": "进阶开发者",
            "openrank_min": 10,
            "openrank_max": 50,
            "tasks": ["feature_development", "bug_fixing", "code_review"]
        },
        "senior": {
            "name": "资深开发者",
            "openrank_min": 50,
            "openrank_max": float('inf'),
            "tasks": ["architecture", "community_governance", "mentoring"]
        }
    }
    
    def __init__(self):
        self.task_database = self._init_task_database()
    
    def _init_task_database(self) -> Dict:
        """初始化任务数据库"""
        return {
            "good_first_issue": {
                "name": "Good First Issue",
                "difficulty": "easy",
                "estimated_time": "2-4小时",
                "skills_required": [],
                "openrank_reward": 1,
                "description": "适合新手的入门任务，通常为文档改进、小bug修复等"
            },
            "documentation": {
                "name": "文档优化",
                "difficulty": "easy",
                "estimated_time": "3-6小时",
                "skills_required": ["markdown", "documentation"],
                "openrank_reward": 2,
                "description": "改进项目文档，包括README、API文档等"
            },
            "testing": {
                "name": "单元测试补充",
                "difficulty": "easy-medium",
                "estimated_time": "4-8小时",
                "skills_required": ["testing", "unit_test"],
                "openrank_reward": 2,
                "description": "为项目添加或完善单元测试"
            },
            "bug_fixing": {
                "name": "Bug修复",
                "difficulty": "medium",
                "estimated_time": "6-12小时",
                "skills_required": ["debugging", "problem_solving"],
                "openrank_reward": 5,
                "description": "修复项目中的bug"
            },
            "feature_development": {
                "name": "功能开发",
                "difficulty": "medium-hard",
                "estimated_time": "1-2周",
                "skills_required": ["coding", "design"],
                "openrank_reward": 10,
                "description": "开发新功能模块"
            },
            "code_review": {
                "name": "代码审查",
                "difficulty": "medium",
                "estimated_time": "2-4小时",
                "skills_required": ["code_review", "best_practices"],
                "openrank_reward": 3,
                "description": "审查他人的PR，提供改进建议"
            },
            "architecture": {
                "name": "架构设计",
                "difficulty": "hard",
                "estimated_time": "2-4周",
                "skills_required": ["architecture", "design_patterns"],
                "openrank_reward": 20,
                "description": "参与项目架构设计和技术决策"
            },
            "community_governance": {
                "name": "社区治理",
                "difficulty": "hard",
                "estimated_time": "持续",
                "skills_required": ["leadership", "communication"],
                "openrank_reward": 15,
                "description": "参与社区治理、制定规范"
            },
            "mentoring": {
                "name": "导师指导",
                "difficulty": "medium",
                "estimated_time": "持续",
                "skills_required": ["teaching", "communication"],
                "openrank_reward": 5,
                "description": "指导新手开发者，帮助其成长"
            }
        }
    
    def classify_developer_level(self, developer_data: Dict) -> str:
        """
        分类开发者层级
        
        Args:
            developer_data: 开发者数据
        
        Returns:
            开发者层级
        """
        openrank = developer_data.get("openrank", 0)
        contributions = developer_data.get("contributions", 0)
        
        # 综合考虑OpenRank和贡献数
        if openrank >= 50 or contributions >= 500:
            return "senior"
        elif openrank >= 10 or contributions >= 50:
            return "intermediate"
        else:
            return "beginner"
    
    def extract_skills(self, developer_data: Dict) -> List[str]:
        """提取开发者技能标签"""
        skills = developer_data.get("skill_tags", [])
        
        # 补充从贡献历史中提取的技能
        contributions = developer_data.get("contribution_history", [])
        for contrib in contributions:
            if "language" in contrib:
                skills.append(contrib["language"])
            if "type" in contrib:
                skills.append(contrib["type"])
        
        # 去重并返回
        return list(set(skills))
    
    def plan_contribution_path(self, developer_data: Dict,
                              project_data: Dict,
                              target_openrank: Optional[float] = None) -> Dict:
        """
        规划贡献路径
        
        Args:
            developer_data: 开发者数据
            project_data: 项目数据
            target_openrank: 目标OpenRank分数
        
        Returns:
            路径规划结果
        """
        try:
            # 分类开发者层级
            level = self.classify_developer_level(developer_data)
            level_info = self.DEVELOPER_LEVELS[level]
            
            # 提取技能
            skills = self.extract_skills(developer_data)
            
            # 分析项目需求
            project_needs = self._analyze_project_needs(project_data)
            
            # 匹配任务
            matched_tasks = self._match_tasks(skills, level, project_needs)
            
            # 生成路径
            path = self._generate_path(matched_tasks, developer_data, target_openrank)
            
            # 计算成长里程碑
            milestones = self._calculate_milestones(
                developer_data, path, target_openrank
            )
            
            result = {
                "developer_level": level,
                "level_name": level_info["name"],
                "current_openrank": developer_data.get("openrank", 0),
                "current_skills": skills,
                "recommended_tasks": matched_tasks,
                "path": path,
                "milestones": milestones,
                "estimated_completion": self._estimate_completion_time(path),
                "projected_openrank": self._project_openrank(
                    developer_data.get("openrank", 0), path
                )
            }
            
            _logger.info(f"为开发者规划路径完成: {level}")
            return result
            
        except Exception as e:
            _logger.error(f"路径规划失败: {str(e)}")
            raise
    
    def _analyze_project_needs(self, project_data: Dict) -> Dict:
        """分析项目需求"""
        needs = {
            "priority_areas": [],
            "skill_gaps": [],
            "task_types": []
        }
        
        # 分析健康度评估结果
        health_assessment = project_data.get("health_assessment", {})
        dimension_scores = health_assessment.get("dimension_scores", {})
        
        # 识别需要改进的维度
        if dimension_scores.get("code_activity", 1.0) < 0.6:
            needs["priority_areas"].append("代码活跃度")
            needs["task_types"].extend(["feature_development", "bug_fixing"])
        
        if dimension_scores.get("issue_efficiency", 1.0) < 0.6:
            needs["priority_areas"].append("Issue处理")
            needs["task_types"].extend(["bug_fixing", "code_review"])
        
        if dimension_scores.get("contributor_ecology", 1.0) < 0.6:
            needs["priority_areas"].append("贡献者生态")
            needs["task_types"].extend(["good_first_issue", "documentation", "mentoring"])
        
        return needs
    
    def _match_tasks(self, skills: List[str], level: str,
                    project_needs: Dict) -> List[Dict]:
        """匹配任务"""
        level_info = self.DEVELOPER_LEVELS[level]
        available_tasks = level_info["tasks"]
        
        matched = []
        
        for task_key in available_tasks:
            if task_key not in self.task_database:
                continue
            
            task_info = self.task_database[task_key].copy()
            task_info["task_key"] = task_key
            
            # 计算匹配度
            match_score = self._calculate_task_match_score(
                task_info, skills, project_needs
            )
            
            task_info["match_score"] = match_score
            matched.append(task_info)
        
        # 按匹配度排序
        matched.sort(key=lambda x: x["match_score"], reverse=True)
        
        return matched
    
    def _calculate_task_match_score(self, task: Dict, skills: List[str],
                                   project_needs: Dict) -> float:
        """计算任务匹配度"""
        score = 0.0
        
        # 技能匹配度
        required_skills = task.get("skills_required", [])
        if required_skills:
            matched_skills = set(required_skills) & set(skills)
            skill_match_ratio = len(matched_skills) / len(required_skills)
            score += skill_match_ratio * 0.5
        else:
            # 不需要特定技能的任务，匹配度较高
            score += 0.5
        
        # 项目需求匹配度
        if task["task_key"] in project_needs.get("task_types", []):
            score += 0.5
        
        return score
    
    def _generate_path(self, tasks: List[Dict], developer_data: Dict,
                      target_openrank: Optional[float]) -> List[Dict]:
        """生成路径"""
        current_openrank = developer_data.get("openrank", 0)
        
        path = []
        accumulated_openrank = current_openrank
        
        for task in tasks[:5]:  # 选择前5个任务
            step = {
                "step": len(path) + 1,
                "task": task["task_key"],
                "task_name": task["name"],
                "difficulty": task["difficulty"],
                "estimated_time": task["estimated_time"],
                "openrank_reward": task["openrank_reward"],
                "description": task["description"],
                "prerequisites": []
            }
            
            if path:
                step["prerequisites"] = [path[-1]["task"]]
            
            path.append(step)
            accumulated_openrank += task["openrank_reward"]
            
            # 如果达到目标，停止
            if target_openrank and accumulated_openrank >= target_openrank:
                break
        
        return path
    
    def _calculate_milestones(self, developer_data: Dict, path: List[Dict],
                            target_openrank: Optional[float]) -> List[Dict]:
        """计算成长里程碑"""
        milestones = []
        current_openrank = developer_data.get("openrank", 0)
        accumulated = current_openrank
        
        milestone_thresholds = [10, 25, 50, 100, 200]
        
        for threshold in milestone_thresholds:
            if threshold > current_openrank:
                # 计算达到该里程碑需要的任务
                needed_openrank = threshold - accumulated
                tasks_needed = []
                
                for task in path:
                    if needed_openrank > 0:
                        tasks_needed.append(task["task"])
                        needed_openrank -= task["openrank_reward"]
                        accumulated += task["openrank_reward"]
                
                milestones.append({
                    "milestone": f"OpenRank达到{threshold}",
                    "target_openrank": threshold,
                    "tasks_required": tasks_needed,
                    "estimated_time": f"{len(tasks_needed) * 2}周"
                })
        
        return milestones
    
    def _estimate_completion_time(self, path: List[Dict]) -> str:
        """估算完成时间"""
        total_hours = 0
        for step in path:
            time_str = step.get("estimated_time", "0小时")
            # 简化解析
            if "小时" in time_str:
                hours = int(time_str.split("-")[0].strip())
                total_hours += hours
            elif "周" in time_str:
                weeks = int(time_str.split("-")[0].strip())
                total_hours += weeks * 40  # 假设每周40小时
        
        if total_hours < 40:
            return f"{total_hours}小时"
        else:
            weeks = total_hours / 40
            return f"{weeks:.1f}周"
    
    def _project_openrank(self, current_openrank: float,
                         path: List[Dict]) -> float:
        """预测完成路径后的OpenRank"""
        total_reward = sum(step["openrank_reward"] for step in path)
        return current_openrank + total_reward



