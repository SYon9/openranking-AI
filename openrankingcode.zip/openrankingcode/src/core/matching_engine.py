"""
GNN协作匹配引擎
基于图神经网络实现项目-开发者-机构三方协同匹配
"""
import numpy as np
from typing import Dict, List, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch_geometric.data import Data
    from torch_geometric.nn import GCNConv
    TORCH_GEOMETRIC_AVAILABLE = True
except ImportError:
    TORCH_GEOMETRIC_AVAILABLE = False

from src.utils.logger import get_logger

_logger = get_logger(__name__)


class GNNMatchingEngine:
    """GNN协作匹配引擎"""
    
    def __init__(self, input_dim: int = 64, hidden_dim: int = 64,
                 output_dim: int = 128, num_layers: int = 2):
        """
        初始化匹配引擎
        
        Args:
            input_dim: 输入特征维度
            hidden_dim: 隐藏层维度
            output_dim: 输出嵌入维度
            num_layers: GCN层数
        """
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.num_layers = num_layers
        
        self.model = None
        self.graph_data = None
        self.node_embeddings = None
        
        if TORCH_GEOMETRIC_AVAILABLE:
            self._build_model()
    
    def _build_model(self):
        """构建GCN模型"""
        if not TORCH_GEOMETRIC_AVAILABLE:
            return
        
        class GCNModel(nn.Module):
            def __init__(self, input_dim, hidden_dim, output_dim, num_layers):
                super(GCNModel, self).__init__()
                self.convs = nn.ModuleList()
                self.convs.append(GCNConv(input_dim, hidden_dim))
                
                for _ in range(num_layers - 2):
                    self.convs.append(GCNConv(hidden_dim, hidden_dim))
                
                if num_layers > 1:
                    self.convs.append(GCNConv(hidden_dim, output_dim))
                else:
                    self.convs.append(GCNConv(input_dim, output_dim))
            
            def forward(self, x, edge_index):
                for i, conv in enumerate(self.convs):
                    x = conv(x, edge_index)
                    if i < len(self.convs) - 1:
                        x = F.relu(x)
                        x = F.dropout(x, training=self.training, p=0.2)
                return x
        
        self.model = GCNModel(
            self.input_dim,
            self.hidden_dim,
            self.output_dim,
            self.num_layers
        )
        
        _logger.info("GCN模型构建完成")
    
    def build_graph(self, projects: List[Dict], contributors: List[Dict],
                   collaborations: List[Dict]) -> Data:
        """
        构建协作网络图
        
        Args:
            projects: 项目列表
            contributors: 贡献者列表
            collaborations: 协作关系列表
        
        Returns:
            PyTorch Geometric Data对象
        """
        if not TORCH_GEOMETRIC_AVAILABLE:
            _logger.warning("PyTorch Geometric未安装，无法构建图")
            return None
        
        try:
            # 构建节点映射
            node_map = {}
            node_features = []
            node_types = []  # 0: project, 1: contributor, 2: institution
            
            # 添加项目节点
            for i, project in enumerate(projects):
                node_map[f"project_{project['repo']}"] = len(node_map)
                node_features.append(self._encode_project_features(project))
                node_types.append(0)
            
            # 添加贡献者节点
            for contributor in contributors:
                node_id = f"contributor_{contributor['id']}"
                if node_id not in node_map:
                    node_map[node_id] = len(node_map)
                    node_features.append(self._encode_contributor_features(contributor))
                    node_types.append(1)
            
            # 构建边
            edge_index = []
            edge_attr = []
            
            for collab in collaborations:
                source_type = collab.get("source_type")
                target_type = collab.get("target_type")
                source_id = collab.get("source_id")
                target_id = collab.get("target_id")
                
                source_node = f"{source_type}_{source_id}"
                target_node = f"{target_type}_{target_id}"
                
                if source_node in node_map and target_node in node_map:
                    edge_index.append([node_map[source_node], node_map[target_node]])
                    edge_attr.append(collab.get("weight", 1.0))
            
            # 转换为PyTorch张量
            x = torch.FloatTensor(node_features)
            edge_index = torch.LongTensor(edge_index).t().contiguous()
            edge_attr = torch.FloatTensor(edge_attr)
            
            graph_data = Data(
                x=x,
                edge_index=edge_index,
                edge_attr=edge_attr
            )
            
            # 保存节点映射信息（添加到图数据属性中）
            graph_data.node_ids = list(node_map.keys())
            graph_data.node_types = node_types
            
            self.graph_data = graph_data
            _logger.info(f"图构建完成: {len(node_map)} 个节点, {len(edge_index[0]) if len(edge_index) > 0 else 0} 条边")
            return graph_data
            
        except Exception as e:
            _logger.error(f"构建图失败: {str(e)}")
            return None
    
    def _encode_project_features(self, project: Dict) -> List[float]:
        """编码项目特征向量"""
        features = []
        
        # OpenRank分数
        metrics = project.get("metrics", {})
        openrank = metrics.get("openrank", {}).get("current_score", 0)
        features.append(min(openrank / 100, 1.0))  # 归一化
        
        # 活跃度
        activity = metrics.get("activity", {}).get("commit_frequency", 0)
        features.append(min(activity / 100, 1.0))
        
        # 贡献者数量
        contributor_count = len(project.get("contributors", []))
        features.append(min(contributor_count / 100, 1.0))
        
        # Issue解决率
        issue_pr = metrics.get("issue_pr", {})
        resolution_rate = issue_pr.get("issue_resolution_rate", 0)
        features.append(resolution_rate)
        
        # 补足到64维（使用0填充或重复特征）
        while len(features) < self.input_dim:
            features.extend(features[:self.input_dim - len(features)])
            if len(features) >= self.input_dim:
                break
        
        return features[:self.input_dim]
    
    def _encode_contributor_features(self, contributor: Dict) -> List[float]:
        """编码贡献者特征向量"""
        features = []
        
        # OpenRank
        openrank = contributor.get("openrank", 0)
        features.append(min(openrank / 100, 1.0))
        
        # 贡献数
        contributions = contributor.get("contributions", 0)
        features.append(min(contributions / 1000, 1.0))
        
        # 技能标签数量
        skill_tags = contributor.get("skill_tags", [])
        features.append(min(len(skill_tags) / 10, 1.0))
        
        # 补足到64维
        while len(features) < self.input_dim:
            features.extend(features[:self.input_dim - len(features)])
            if len(features) >= self.input_dim:
                break
        
        return features[:self.input_dim]
    
    def train(self, graph_data: Data, epochs: int = 200, lr: float = 0.001):
        """训练GCN模型"""
        if not TORCH_GEOMETRIC_AVAILABLE or self.model is None:
            _logger.warning("模型未初始化，无法训练")
            return
        
        try:
            optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
            
            self.model.train()
            for epoch in range(epochs):
                optimizer.zero_grad()
                
                # 前向传播
                embeddings = self.model(graph_data.x, graph_data.edge_index)
                
                # 简化训练：使用节点分类任务
                # 实际应使用链接预测或节点相似度任务
                loss = F.mse_loss(embeddings, graph_data.x[:, :self.output_dim])
                
                loss.backward()
                optimizer.step()
                
                if (epoch + 1) % 50 == 0:
                    _logger.debug(f"Epoch [{epoch+1}/{epochs}], Loss: {loss.item():.4f}")
            
            # 保存节点嵌入
            self.model.eval()
            with torch.no_grad():
                self.node_embeddings = self.model(graph_data.x, graph_data.edge_index)
            
            _logger.info("GCN模型训练完成")
            
        except Exception as e:
            _logger.error(f"模型训练失败: {str(e)}")
    
    def match_project_contributor(self, project_id: str, 
                                 top_k: int = 10) -> List[Dict]:
        """
        匹配项目与贡献者
        
        Args:
            project_id: 项目ID
            top_k: 返回前K个匹配结果
        
        Returns:
            匹配结果列表
        """
        if self.node_embeddings is None:
            _logger.warning("节点嵌入未计算，无法进行匹配")
            return []
        
        try:
            # 找到项目节点（简化实现）
            # 实际应从图数据中正确获取节点信息
            if not hasattr(self.graph_data, 'node_ids'):
                # 如果没有node_ids属性，返回空列表
                return []
            
            project_node_idx = None
            for i, node_id in enumerate(self.graph_data.node_ids):
                if node_id == f"project_{project_id}":
                    project_node_idx = i
                    break
            
            if project_node_idx is None:
                return []
            
            # 计算相似度
            project_embedding = self.node_embeddings[project_node_idx]
            
            similarities = []
            for i, node_id in enumerate(self.graph_data.node_ids):
                if node_id.startswith("contributor_"):
                    contributor_embedding = self.node_embeddings[i]
                    # 余弦相似度
                    sim = F.cosine_similarity(
                        project_embedding.unsqueeze(0),
                        contributor_embedding.unsqueeze(0)
                    ).item()
                    similarities.append({
                        "contributor_id": node_id.replace("contributor_", ""),
                        "similarity": sim,
                        "rank": i
                    })
            
            # 排序并返回Top-K
            similarities.sort(key=lambda x: x["similarity"], reverse=True)
            
            return similarities[:top_k]
            
        except Exception as e:
            _logger.error(f"匹配失败: {str(e)}")
            return []
    
    def match_contributor_contributor(self, contributor_id: str,
                                     top_k: int = 10) -> List[Dict]:
        """匹配贡献者与贡献者（协作伙伴推荐）"""
        # 类似project-contributor匹配逻辑
        return []

