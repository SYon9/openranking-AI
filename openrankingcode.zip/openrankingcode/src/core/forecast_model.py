"""
LSTM时序预测模型
用于健康度趋势预测与风险预警
"""
import numpy as np
import pandas as pd
from typing import List, Tuple, Optional, Dict
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    _logger.warning("PyTorch未安装，LSTM预测功能不可用")

from src.utils.logger import get_logger

_logger = get_logger(__name__)


class LSTMForecastModel:
    """LSTM时序预测模型"""
    
    def __init__(self, input_size: int = 1, hidden_size: int = 64, 
                 num_layers: int = 2, output_size: int = 1, 
                 sequence_length: int = 10):
        """
        初始化LSTM模型
        
        Args:
            input_size: 输入特征维度
            hidden_size: LSTM隐藏层大小
            num_layers: LSTM层数
            output_size: 输出维度
            sequence_length: 输入序列长度
        """
        if not TORCH_AVAILABLE:
            raise ImportError("需要安装PyTorch才能使用LSTM模型")
        
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.output_size = output_size
        self.sequence_length = sequence_length
        
        self.model = None
        self.scaler = None
        self.is_trained = False
    
    def build_model(self):
        """构建LSTM模型"""
        if not TORCH_AVAILABLE:
            return
        
        class LSTMModel(nn.Module):
            def __init__(self, input_size, hidden_size, num_layers, output_size):
                super(LSTMModel, self).__init__()
                self.hidden_size = hidden_size
                self.num_layers = num_layers
                
                self.lstm = nn.LSTM(
                    input_size,
                    hidden_size,
                    num_layers,
                    batch_first=True,
                    dropout=0.2 if num_layers > 1 else 0
                )
                self.fc = nn.Linear(hidden_size, output_size)
            
            def forward(self, x):
                # x shape: (batch, seq_len, input_size)
                out, _ = self.lstm(x)
                # 取最后一个时间步的输出
                out = self.fc(out[:, -1, :])
                return out
        
        self.model = LSTMModel(
            self.input_size,
            self.hidden_size,
            self.num_layers,
            self.output_size
        )
        
        _logger.info("LSTM模型构建完成")
    
    def prepare_data(self, data: List[float], 
                    normalize: bool = True) -> Tuple[np.ndarray, np.ndarray]:
        """
        准备训练数据
        
        Args:
            data: 时间序列数据
            normalize: 是否归一化
        
        Returns:
            (X, y) 训练数据对
        """
        if len(data) < self.sequence_length + 1:
            raise ValueError(f"数据长度不足，需要至少 {self.sequence_length + 1} 个数据点")
        
        # 转换为numpy数组
        data_array = np.array(data).reshape(-1, 1)
        
        # 归一化
        if normalize:
            from sklearn.preprocessing import MinMaxScaler
            self.scaler = MinMaxScaler()
            data_array = self.scaler.fit_transform(data_array)
        
        # 创建序列数据
        X, y = [], []
        for i in range(len(data_array) - self.sequence_length):
            X.append(data_array[i:i + self.sequence_length])
            y.append(data_array[i + self.sequence_length])
        
        return np.array(X), np.array(y)
    
    def train(self, data: List[float], epochs: int = 100, 
             learning_rate: float = 0.001, batch_size: int = 32):
        """
        训练模型
        
        Args:
            data: 训练数据
            epochs: 训练轮数
            learning_rate: 学习率
            batch_size: 批次大小
        """
        if not TORCH_AVAILABLE:
            _logger.error("PyTorch未安装，无法训练模型")
            return
        
        if self.model is None:
            self.build_model()
        
        try:
            # 准备数据
            X, y = self.prepare_data(data)
            
            # 转换为PyTorch张量
            X_tensor = torch.FloatTensor(X)
            y_tensor = torch.FloatTensor(y)
            
            # 定义损失函数和优化器
            criterion = nn.MSELoss()
            optimizer = torch.optim.Adam(self.model.parameters(), lr=learning_rate)
            
            # 训练
            self.model.train()
            for epoch in range(epochs):
                # 随机打乱数据
                indices = np.random.permutation(len(X_tensor))
                X_shuffled = X_tensor[indices]
                y_shuffled = y_tensor[indices]
                
                # 批次训练
                total_loss = 0
                for i in range(0, len(X_shuffled), batch_size):
                    batch_X = X_shuffled[i:i + batch_size]
                    batch_y = y_shuffled[i:i + batch_size]
                    
                    optimizer.zero_grad()
                    outputs = self.model(batch_X)
                    loss = criterion(outputs, batch_y)
                    loss.backward()
                    optimizer.step()
                    
                    total_loss += loss.item()
                
                if (epoch + 1) % 20 == 0:
                    avg_loss = total_loss / (len(X_shuffled) / batch_size)
                    _logger.debug(f"Epoch [{epoch+1}/{epochs}], Loss: {avg_loss:.4f}")
            
            self.is_trained = True
            _logger.info("LSTM模型训练完成")
            
        except Exception as e:
            _logger.error(f"模型训练失败: {str(e)}")
            raise
    
    def predict(self, data: List[float], steps: int = 5) -> List[float]:
        """
        预测未来值
        
        Args:
            data: 历史数据（用于预测）
            steps: 预测步数
        
        Returns:
            预测值列表
        """
        if not TORCH_AVAILABLE or not self.is_trained:
            # 如果模型未训练，使用简单移动平均作为fallback
            _logger.warning("模型未训练，使用移动平均预测")
            return self._simple_forecast(data, steps)
        
        try:
            predictions = []
            current_data = data.copy()
            
            # 归一化
            if self.scaler:
                current_data_normalized = self.scaler.transform(
                    np.array(current_data).reshape(-1, 1)
                ).flatten().tolist()
            else:
                current_data_normalized = current_data
            
            self.model.eval()
            with torch.no_grad():
                for _ in range(steps):
                    # 取最后sequence_length个数据点
                    sequence = current_data_normalized[-self.sequence_length:]
                    X = torch.FloatTensor([sequence]).unsqueeze(-1)
                    
                    # 预测
                    pred = self.model(X).item()
                    predictions.append(pred)
                    
                    # 更新序列
                    current_data_normalized.append(pred)
            
            # 反归一化
            if self.scaler:
                predictions = self.scaler.inverse_transform(
                    np.array(predictions).reshape(-1, 1)
                ).flatten().tolist()
            
            return predictions
            
        except Exception as e:
            _logger.error(f"预测失败: {str(e)}")
            return self._simple_forecast(data, steps)
    
    def _simple_forecast(self, data: List[float], steps: int) -> List[float]:
        """简单移动平均预测（fallback）"""
        if not data:
            return [0.0] * steps
        
        window = min(5, len(data))
        avg = np.mean(data[-window:])
        trend = (data[-1] - data[-window]) / window if len(data) > window else 0
        
        predictions = []
        for i in range(steps):
            pred = avg + trend * (i + 1)
            predictions.append(max(0, pred))  # 确保非负
        
        return predictions
    
    def detect_anomaly(self, historical_data: List[float], 
                      threshold: float = 2.0) -> Dict:
        """
        异常检测
        
        Args:
            historical_data: 历史数据
            threshold: 异常检测阈值（标准差倍数）
        
        Returns:
            异常检测结果
        """
        if len(historical_data) < 10:
            return {"has_anomaly": False, "anomalies": []}
        
        try:
            # 计算统计量
            mean = np.mean(historical_data)
            std = np.std(historical_data)
            
            # 检测异常点
            anomalies = []
            for i, value in enumerate(historical_data):
                z_score = abs((value - mean) / std) if std > 0 else 0
                if z_score > threshold:
                    anomalies.append({
                        "index": i,
                        "value": value,
                        "z_score": z_score,
                        "timestamp": i  # 简化处理
                    })
            
            return {
                "has_anomaly": len(anomalies) > 0,
                "anomalies": anomalies,
                "mean": mean,
                "std": std
            }
            
        except Exception as e:
            _logger.error(f"异常检测失败: {str(e)}")
            return {"has_anomaly": False, "anomalies": []}



