"""
数据采集模块
负责从OpenDigger、GitHub、Gitee等数据源采集开源项目数据
"""
import requests
import time
import json
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from pathlib import Path
from loguru import logger

from src.config import OPENDIGGER_API_URL, OPENDIGGER_API_KEY, RAW_DATA_DIR
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class DataCollector:
    """数据采集器"""
    
    def __init__(self):
        self.opendigger_url = OPENDIGGER_API_URL
        self.api_key = OPENDIGGER_API_KEY
        self.session = requests.Session()
        if self.api_key:
            self.session.headers.update({"Authorization": f"Bearer {self.api_key}"})
        self.session.headers.update({"Content-Type": "application/json"})
    
    def collect_project_metrics(self, repo: str, start_date: Optional[str] = None, 
                                end_date: Optional[str] = None) -> Dict:
        """
        采集项目指标数据
        
        Args:
            repo: 仓库名称，格式为 'owner/repo'
            start_date: 开始日期，格式 'YYYY-MM-DD'
            end_date: 结束日期，格式 'YYYY-MM-DD'
        
        Returns:
            项目指标数据字典
        """
        try:
            if not start_date:
                start_date = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
            if not end_date:
                end_date = datetime.now().strftime("%Y-%m-%d")
            
            # 获取OpenRank指标
            openrank_data = self._get_openrank(repo, start_date, end_date)
            
            # 获取活跃度指标
            activity_data = self._get_activity(repo, start_date, end_date)
            
            # 获取贡献者数据
            contributor_data = self._get_contributors(repo)
            
            # 获取Issue/PR数据
            issue_pr_data = self._get_issue_pr_metrics(repo, start_date, end_date)
            
            result = {
                "repo": repo,
                "start_date": start_date,
                "end_date": end_date,
                "collected_at": datetime.now().isoformat(),
                "openrank": openrank_data,
                "activity": activity_data,
                "contributors": contributor_data,
                "issue_pr": issue_pr_data
            }
            
            # 保存原始数据
            self._save_raw_data(repo, result)
            
            _logger.info(f"成功采集项目 {repo} 的数据")
            return result
            
        except Exception as e:
            _logger.error(f"采集项目 {repo} 数据失败: {str(e)}")
            raise
    
    def _get_openrank(self, repo: str, start_date: str, end_date: str) -> Dict:
        """获取OpenRank分数"""
        try:
            url = f"{self.opendigger_url}/api/v1/repos/{repo}/openrank"
            params = {
                "startDate": start_date,
                "endDate": end_date,
                "period": "month"
            }
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            _logger.warning(f"获取OpenRank数据失败: {str(e)}")
            return {}
    
    def _get_activity(self, repo: str, start_date: str, end_date: str) -> Dict:
        """获取活跃度指标"""
        try:
            url = f"{self.opendigger_url}/api/v1/repos/{repo}/activity"
            params = {
                "startDate": start_date,
                "endDate": end_date
            }
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            _logger.warning(f"获取活跃度数据失败: {str(e)}")
            return {}
    
    def _get_contributors(self, repo: str) -> Dict:
        """获取贡献者数据"""
        try:
            url = f"{self.opendigger_url}/api/v1/repos/{repo}/contributors"
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            _logger.warning(f"获取贡献者数据失败: {str(e)}")
            return {}
    
    def _get_issue_pr_metrics(self, repo: str, start_date: str, end_date: str) -> Dict:
        """获取Issue/PR指标"""
        try:
            url = f"{self.opendigger_url}/api/v1/repos/{repo}/issues"
            params = {
                "startDate": start_date,
                "endDate": end_date
            }
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            _logger.warning(f"获取Issue/PR数据失败: {str(e)}")
            return {}
    
    def _save_raw_data(self, repo: str, data: Dict):
        """保存原始数据到文件"""
        safe_repo_name = repo.replace("/", "_")
        file_path = RAW_DATA_DIR / f"{safe_repo_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        _logger.debug(f"原始数据已保存到 {file_path}")
    
    def batch_collect(self, repos: List[str], delay: float = 1.0) -> List[Dict]:
        """
        批量采集多个项目的数据
        
        Args:
            repos: 仓库名称列表
            delay: 请求间隔（秒），避免API限流
        
        Returns:
            采集结果列表
        """
        results = []
        for i, repo in enumerate(repos):
            try:
                result = self.collect_project_metrics(repo)
                results.append(result)
                _logger.info(f"进度: {i+1}/{len(repos)} - {repo}")
                
                # 避免API限流
                if i < len(repos) - 1:
                    time.sleep(delay)
            except Exception as e:
                _logger.error(f"批量采集失败 ({repo}): {str(e)}")
                results.append({"repo": repo, "error": str(e)})
        
        return results



