"""
数据存储模块
负责数据存储到SQLite、Redis、IoTDB等
"""
import sqlite3
import redis
import json
import pandas as pd
from typing import Dict, List, Optional, Any
from datetime import datetime
from pathlib import Path

from src.config import (
    SQLITE_DB_PATH, REDIS_HOST, REDIS_PORT, REDIS_DB,
    IOTDB_HOST, IOTDB_PORT, IOTDB_USER, IOTDB_PASSWORD
)
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class DataStorage:
    """数据存储器"""
    
    def __init__(self):
        self.db_path = Path(SQLITE_DB_PATH)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 初始化Redis连接
        try:
            self.redis_client = redis.Redis(
                host=REDIS_HOST,
                port=REDIS_PORT,
                db=REDIS_DB,
                decode_responses=True
            )
            self.redis_client.ping()
            _logger.info("Redis连接成功")
        except Exception as e:
            _logger.warning(f"Redis连接失败: {str(e)}")
            self.redis_client = None
        
        # 初始化SQLite
        self._init_sqlite()
        
        # IoTDB连接将在需要时初始化
        self.iotdb_session = None
    
    def _init_sqlite(self):
        """初始化SQLite数据库表结构"""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()
        
        # 项目表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                repo TEXT UNIQUE NOT NULL,
                name TEXT,
                owner TEXT,
                description TEXT,
                language TEXT,
                created_at TIMESTAMP,
                updated_at TIMESTAMP,
                last_collected_at TIMESTAMP,
                metadata TEXT,
                UNIQUE(repo)
            )
        """)
        
        # 指标表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS project_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                repo TEXT NOT NULL,
                metric_type TEXT NOT NULL,
                metric_key TEXT NOT NULL,
                metric_value REAL,
                metric_data TEXT,
                collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (repo) REFERENCES projects(repo),
                UNIQUE(repo, metric_type, metric_key, collected_at)
            )
        """)
        
        # 贡献者表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS contributors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                repo TEXT NOT NULL,
                contributor_id TEXT NOT NULL,
                login TEXT,
                contributions INTEGER DEFAULT 0,
                openrank REAL DEFAULT 0,
                skill_tags TEXT,
                first_contribution_at TIMESTAMP,
                last_contribution_at TIMESTAMP,
                FOREIGN KEY (repo) REFERENCES projects(repo),
                UNIQUE(repo, contributor_id)
            )
        """)
        
        # 时间序列指标表（用于IoTDB同步）
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS timeseries_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                repo TEXT NOT NULL,
                metric_name TEXT NOT NULL,
                timestamp TIMESTAMP NOT NULL,
                value REAL,
                tags TEXT,
                FOREIGN KEY (repo) REFERENCES projects(repo),
                UNIQUE(repo, metric_name, timestamp)
            )
        """)
        
        # 创建索引
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_repo ON projects(repo)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_metrics_repo ON project_metrics(repo)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_contributors_repo ON contributors(repo)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_timeseries_repo_time ON timeseries_metrics(repo, timestamp)")
        
        conn.commit()
        conn.close()
        _logger.info("SQLite数据库初始化完成")
    
    def save_project(self, processed_data: Dict) -> bool:
        """保存项目数据"""
        try:
            repo = processed_data.get("repo")
            if not repo:
                raise ValueError("repo字段不能为空")
            
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            # 保存或更新项目基本信息
            cursor.execute("""
                INSERT OR REPLACE INTO projects 
                (repo, name, owner, updated_at, last_collected_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                repo,
                repo.split("/")[-1] if "/" in repo else repo,
                repo.split("/")[0] if "/" in repo else None,
                datetime.now().isoformat(),
                processed_data.get("processed_at"),
                json.dumps(processed_data.get("features", {}))
            ))
            
            # 保存指标数据
            metrics = processed_data.get("metrics", {})
            for metric_type, metric_data in metrics.items():
                if isinstance(metric_data, dict):
                    for key, value in metric_data.items():
                        if isinstance(value, (int, float)):
                            cursor.execute("""
                                INSERT OR REPLACE INTO project_metrics
                                (repo, metric_type, metric_key, metric_value, collected_at)
                                VALUES (?, ?, ?, ?, ?)
                            """, (
                                repo,
                                metric_type,
                                key,
                                value,
                                processed_data.get("processed_at")
                            ))
            
            # 保存贡献者数据
            contributors = processed_data.get("contributors", [])
            for contributor in contributors:
                cursor.execute("""
                    INSERT OR REPLACE INTO contributors
                    (repo, contributor_id, login, contributions, openrank, skill_tags)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    repo,
                    contributor.get("id"),
                    contributor.get("login"),
                    contributor.get("contributions", 0),
                    contributor.get("openrank", 0),
                    json.dumps(contributor.get("skill_tags", []))
                ))
            
            conn.commit()
            conn.close()
            
            # 缓存到Redis
            if self.redis_client:
                cache_key = f"project:{repo}"
                self.redis_client.setex(
                    cache_key,
                    3600,  # 1小时过期
                    json.dumps(processed_data, ensure_ascii=False)
                )
            
            _logger.info(f"项目 {repo} 数据已保存")
            return True
            
        except Exception as e:
            _logger.error(f"保存项目数据失败: {str(e)}")
            return False
    
    def get_project(self, repo: str, use_cache: bool = True) -> Optional[Dict]:
        """获取项目数据"""
        try:
            # 先从Redis缓存获取
            if use_cache and self.redis_client:
                cache_key = f"project:{repo}"
                cached_data = self.redis_client.get(cache_key)
                if cached_data:
                    return json.loads(cached_data)
            
            # 从SQLite获取
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM projects WHERE repo = ?", (repo,))
            project_row = cursor.fetchone()
            
            if not project_row:
                return None
            
            # 构建项目数据
            project_data = {
                "repo": project_row[1],
                "name": project_row[2],
                "metrics": {},
                "contributors": []
            }
            
            # 获取指标
            cursor.execute("""
                SELECT metric_type, metric_key, metric_value 
                FROM project_metrics 
                WHERE repo = ? 
                ORDER BY collected_at DESC
            """, (repo,))
            
            for metric_type, metric_key, metric_value in cursor.fetchall():
                if metric_type not in project_data["metrics"]:
                    project_data["metrics"][metric_type] = {}
                project_data["metrics"][metric_type][metric_key] = metric_value
            
            # 获取贡献者
            cursor.execute("""
                SELECT contributor_id, login, contributions, openrank, skill_tags
                FROM contributors
                WHERE repo = ?
            """, (repo,))
            
            for row in cursor.fetchall():
                project_data["contributors"].append({
                    "id": row[0],
                    "login": row[1],
                    "contributions": row[2],
                    "openrank": row[3],
                    "skill_tags": json.loads(row[4]) if row[4] else []
                })
            
            conn.close()
            return project_data
            
        except Exception as e:
            _logger.error(f"获取项目数据失败: {str(e)}")
            return None
    
    def save_timeseries_metric(self, repo: str, metric_name: str, 
                               value: float, timestamp: Optional[datetime] = None, 
                               tags: Optional[Dict] = None):
        """保存时间序列指标（同时存入SQLite和IoTDB）"""
        if not timestamp:
            timestamp = datetime.now()
        
        try:
            # 保存到SQLite
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT OR REPLACE INTO timeseries_metrics
                (repo, metric_name, timestamp, value, tags)
                VALUES (?, ?, ?, ?, ?)
            """, (
                repo,
                metric_name,
                timestamp.isoformat(),
                value,
                json.dumps(tags) if tags else None
            ))
            
            conn.commit()
            conn.close()
            
            # 同步到IoTDB（如果已初始化）
            if self.iotdb_session:
                self._save_to_iotdb(repo, metric_name, value, timestamp, tags)
            
            _logger.debug(f"时间序列指标已保存: {repo}/{metric_name}")
            
        except Exception as e:
            _logger.error(f"保存时间序列指标失败: {str(e)}")
    
    def _save_to_iotdb(self, repo: str, metric_name: str, value: float,
                      timestamp: datetime, tags: Optional[Dict]):
        """保存数据到IoTDB"""
        # IoTDB集成将在后续实现
        pass
    
    def get_timeseries_metrics(self, repo: str, metric_name: str,
                               start_time: datetime, end_time: datetime) -> pd.DataFrame:
        """获取时间序列指标"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            
            query = """
                SELECT timestamp, value, tags
                FROM timeseries_metrics
                WHERE repo = ? AND metric_name = ?
                AND timestamp >= ? AND timestamp <= ?
                ORDER BY timestamp
            """
            
            df = pd.read_sql_query(
                query,
                conn,
                params=(repo, metric_name, start_time.isoformat(), end_time.isoformat()),
                parse_dates=['timestamp']
            )
            
            conn.close()
            return df
            
        except Exception as e:
            _logger.error(f"获取时间序列指标失败: {str(e)}")
            return pd.DataFrame()



