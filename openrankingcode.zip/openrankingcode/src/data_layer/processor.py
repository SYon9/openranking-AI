"""
数据治理模块
负责数据清洗、脱敏、标准化、特征提取等
"""
import pandas as pd
import numpy as np
import json
import re
from typing import Dict, List, Optional, Any
from datetime import datetime
from pathlib import Path
import jieba
import jieba.analyse

from src.config import PROCESSED_DATA_DIR
from src.utils.logger import get_logger

_logger = get_logger(__name__)

# 初始化jieba分词
jieba.initialize()

# 技术领域词典（示例，实际应更完善）
TECH_KEYWORDS = {
    "Java", "Python", "JavaScript", "TypeScript", "Go", "Rust", "C++", "C#",
    "React", "Vue", "Angular", "Spring", "Django", "Flask",
    "Kubernetes", "Docker", "微服务", "分布式",
    "时序数据库", "IoTDB", "InfluxDB", "时序数据",
    "机器学习", "深度学习", "AI", "NLP", "LLM",
    "前端", "后端", "全栈", "DevOps", "CI/CD"
}


class DataProcessor:
    """数据处理器"""
    
    def __init__(self):
        self.processed_dir = PROCESSED_DATA_DIR
        self.processed_dir.mkdir(parents=True, exist_ok=True)
    
    def process_project_data(self, raw_data: Dict) -> Dict:
        """
        处理项目原始数据
        
        Args:
            raw_data: 原始数据字典
        
        Returns:
            处理后的数据字典
        """
        try:
            processed = {
                "repo": raw_data.get("repo"),
                "processed_at": datetime.now().isoformat(),
                "metrics": {},
                "contributors": [],
                "features": {}
            }
            
            # 处理指标数据
            if "openrank" in raw_data:
                processed["metrics"]["openrank"] = self._process_openrank(raw_data["openrank"])
            
            if "activity" in raw_data:
                processed["metrics"]["activity"] = self._process_activity(raw_data["activity"])
            
            if "issue_pr" in raw_data:
                processed["metrics"]["issue_pr"] = self._process_issue_pr(raw_data["issue_pr"])
            
            # 处理贡献者数据
            if "contributors" in raw_data:
                processed["contributors"] = self._process_contributors(raw_data["contributors"])
            
            # 特征提取
            processed["features"] = self._extract_features(processed)
            
            # 保存处理后的数据
            self._save_processed_data(processed)
            
            _logger.info(f"成功处理项目 {processed['repo']} 的数据")
            return processed
            
        except Exception as e:
            _logger.error(f"处理数据失败: {str(e)}")
            raise
    
    def _process_openrank(self, openrank_data: Dict) -> Dict:
        """处理OpenRank数据"""
        if not openrank_data:
            return {}
        
        try:
            # 提取OpenRank分数时间序列
            if isinstance(openrank_data, list):
                df = pd.DataFrame(openrank_data)
                return {
                    "current_score": df["openrank"].iloc[-1] if "openrank" in df.columns else 0,
                    "max_score": df["openrank"].max() if "openrank" in df.columns else 0,
                    "min_score": df["openrank"].min() if "openrank" in df.columns else 0,
                    "avg_score": df["openrank"].mean() if "openrank" in df.columns else 0,
                    "trend": "increasing" if df["openrank"].iloc[-1] > df["openrank"].iloc[0] else "decreasing",
                    "timeseries": df.to_dict("records") if len(df) > 0 else []
                }
            return openrank_data
        except Exception as e:
            _logger.warning(f"处理OpenRank数据失败: {str(e)}")
            return {}
    
    def _process_activity(self, activity_data: Dict) -> Dict:
        """处理活跃度数据"""
        if not activity_data:
            return {}
        
        try:
            # 标准化活跃度指标
            return {
                "commit_count": activity_data.get("commit_count", 0),
                "commit_frequency": activity_data.get("commit_frequency", 0),
                "active_days": activity_data.get("active_days", 0),
                "active_ratio": activity_data.get("active_ratio", 0)
            }
        except Exception as e:
            _logger.warning(f"处理活跃度数据失败: {str(e)}")
            return {}
    
    def _process_issue_pr(self, issue_pr_data: Dict) -> Dict:
        """处理Issue/PR数据"""
        if not issue_pr_data:
            return {}
        
        try:
            open_issues = issue_pr_data.get("open_issues", 0)
            closed_issues = issue_pr_data.get("closed_issues", 0)
            total_issues = open_issues + closed_issues
            
            open_prs = issue_pr_data.get("open_prs", 0)
            merged_prs = issue_pr_data.get("merged_prs", 0)
            total_prs = open_prs + merged_prs
            
            return {
                "open_issues": open_issues,
                "closed_issues": closed_issues,
                "total_issues": total_issues,
                "issue_resolution_rate": closed_issues / total_issues if total_issues > 0 else 0,
                "open_prs": open_prs,
                "merged_prs": merged_prs,
                "total_prs": total_prs,
                "pr_merge_rate": merged_prs / total_prs if total_prs > 0 else 0,
                "avg_resolution_time": issue_pr_data.get("avg_resolution_time", 0),
                "issue_backlog_ratio": open_issues / total_issues if total_issues > 0 else 0
            }
        except Exception as e:
            _logger.warning(f"处理Issue/PR数据失败: {str(e)}")
            return {}
    
    def _process_contributors(self, contributors_data: Dict) -> List[Dict]:
        """处理贡献者数据（脱敏）"""
        if not contributors_data:
            return []
        
        try:
            contributors = contributors_data.get("data", [])
            processed = []
            
            for contributor in contributors:
                # 脱敏处理：仅保留必要信息
                processed_contributor = {
                    "id": self._hash_id(contributor.get("id", "")),  # 哈希处理
                    "login": contributor.get("login", ""),  # 公开信息保留
                    "contributions": contributor.get("contributions", 0),
                    "openrank": contributor.get("openrank", 0),
                    # 不保留邮箱、真实姓名等敏感信息
                }
                
                # 提取技能标签（如果有commit message等信息）
                if "commits" in contributor:
                    processed_contributor["skill_tags"] = self._extract_skill_tags(
                        contributor.get("commits", [])
                    )
                
                processed.append(processed_contributor)
            
            return processed
        except Exception as e:
            _logger.warning(f"处理贡献者数据失败: {str(e)}")
            return []
    
    def _extract_skill_tags(self, commits: List[Dict]) -> List[str]:
        """从commit信息中提取技能标签"""
        if not commits:
            return []
        
        try:
            # 合并所有commit message
            texts = [commit.get("message", "") for commit in commits[:100]]  # 限制数量
            combined_text = " ".join(texts)
            
            # 使用TF-IDF提取关键词
            keywords = jieba.analyse.extract_tags(
                combined_text,
                topK=10,
                withWeight=False,
                allowPOS=('n', 'vn', 'v')
            )
            
            # 过滤出技术关键词
            skill_tags = [kw for kw in keywords if kw in TECH_KEYWORDS or len(kw) > 1]
            
            return skill_tags[:5]  # 最多返回5个标签
        except Exception as e:
            _logger.warning(f"提取技能标签失败: {str(e)}")
            return []
    
    def _extract_features(self, processed_data: Dict) -> Dict:
        """提取特征向量"""
        try:
            features = {}
            
            # 数值特征
            metrics = processed_data.get("metrics", {})
            features["openrank_score"] = metrics.get("openrank", {}).get("current_score", 0)
            features["commit_frequency"] = metrics.get("activity", {}).get("commit_frequency", 0)
            features["issue_resolution_rate"] = metrics.get("issue_pr", {}).get("issue_resolution_rate", 0)
            features["contributor_count"] = len(processed_data.get("contributors", []))
            
            # 计算综合活跃度
            features["overall_activity"] = (
                features["openrank_score"] * 0.4 +
                features["commit_frequency"] * 0.3 +
                features["issue_resolution_rate"] * 0.3
            )
            
            return features
        except Exception as e:
            _logger.warning(f"提取特征失败: {str(e)}")
            return {}
    
    def _hash_id(self, id_str: str) -> str:
        """哈希ID用于脱敏"""
        import hashlib
        return hashlib.md5(id_str.encode()).hexdigest()[:16]
    
    def _save_processed_data(self, processed_data: Dict):
        """保存处理后的数据"""
        repo = processed_data.get("repo", "unknown")
        safe_repo_name = repo.replace("/", "_")
        file_path = self.processed_dir / f"{safe_repo_name}_processed.json"
        
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(processed_data, f, ensure_ascii=False, indent=2)
        
        _logger.debug(f"处理后的数据已保存到 {file_path}")
    
    def normalize_data(self, data: Any) -> Any:
        """数据标准化（统一格式、时间戳等）"""
        if isinstance(data, dict):
            normalized = {}
            for key, value in data.items():
                normalized[key.lower().replace(" ", "_")] = self.normalize_data(value)
            return normalized
        elif isinstance(data, list):
            return [self.normalize_data(item) for item in data]
        elif isinstance(data, str):
            # 标准化时间戳格式
            if re.match(r'\d{4}-\d{2}-\d{2}', data):
                try:
                    dt = datetime.fromisoformat(data.replace("Z", "+00:00"))
                    return dt.isoformat()
                except:
                    return data
            return data.strip()
        else:
            return data



