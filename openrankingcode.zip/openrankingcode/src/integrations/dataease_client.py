"""
DataEase可视化客户端集成
用于创建和更新可视化仪表板
"""
import requests
from typing import Dict, List, Optional
import json

from src.config import DATAEASE_API_URL, DATAEASE_USERNAME, DATAEASE_PASSWORD
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class DataEaseClient:
    """DataEase客户端"""
    
    def __init__(self):
        self.base_url = DATAEASE_API_URL.rstrip('/')
        self.username = DATAEASE_USERNAME
        self.password = DATAEASE_PASSWORD
        self.token = None
        self.session = requests.Session()
        
        # 尝试登录
        self._login()
    
    def _login(self) -> bool:
        """登录DataEase获取token"""
        try:
            url = f"{self.base_url}/api/auth/login"
            data = {
                "username": self.username,
                "password": self.password
            }
            
            response = self.session.post(url, json=data, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            self.token = result.get("data", {}).get("token")
            
            if self.token:
                self.session.headers.update({
                    "Authorization": f"Bearer {self.token}"
                })
                _logger.info("DataEase登录成功")
                return True
            else:
                _logger.warning("DataEase登录失败：未获取到token")
                return False
                
        except Exception as e:
            _logger.warning(f"DataEase登录失败: {str(e)}")
            return False
    
    def create_dashboard(self, name: str, description: str = "") -> Optional[str]:
        """
        创建仪表板
        
        Returns:
            仪表板ID
        """
        if not self.token:
            _logger.warning("未登录，无法创建仪表板")
            return None
        
        try:
            url = f"{self.base_url}/api/dataset/panel/list"
            data = {
                "name": name,
                "description": description,
                "type": "panel"
            }
            
            response = self.session.post(url, json=data, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            dashboard_id = result.get("data", {}).get("id")
            
            if dashboard_id:
                _logger.info(f"创建仪表板成功: {name} (ID: {dashboard_id})")
                return dashboard_id
            else:
                _logger.warning("创建仪表板失败：未获取到ID")
                return None
                
        except Exception as e:
            _logger.error(f"创建仪表板失败: {str(e)}")
            return None
    
    def create_chart(self, dashboard_id: str, chart_config: Dict) -> Optional[str]:
        """
        创建图表
        
        Args:
            dashboard_id: 仪表板ID
            chart_config: 图表配置
        
        Returns:
            图表ID
        """
        if not self.token:
            return None
        
        try:
            url = f"{self.base_url}/api/panel/component/add"
            data = {
                "panelId": dashboard_id,
                "config": json.dumps(chart_config)
            }
            
            response = self.session.post(url, json=data, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            chart_id = result.get("data", {}).get("id")
            
            if chart_id:
                _logger.debug(f"创建图表成功: {chart_id}")
                return chart_id
            return None
            
        except Exception as e:
            _logger.error(f"创建图表失败: {str(e)}")
            return None
    
    def create_health_score_card(self, dashboard_id: str, 
                               project_name: str, score: float) -> Optional[str]:
        """创建健康度评分卡片"""
        chart_config = {
            "type": "score",
            "title": f"{project_name} 健康度评分",
            "value": score,
            "max": 100,
            "format": "0.0"
        }
        return self.create_chart(dashboard_id, chart_config)
    
    def create_line_chart(self, dashboard_id: str, title: str,
                         data: List[Dict], x_field: str, y_field: str) -> Optional[str]:
        """创建折线图"""
        chart_config = {
            "type": "line",
            "title": title,
            "data": data,
            "xField": x_field,
            "yField": y_field
        }
        return self.create_chart(dashboard_id, chart_config)
    
    def create_bar_chart(self, dashboard_id: str, title: str,
                        data: List[Dict], x_field: str, y_field: str) -> Optional[str]:
        """创建柱状图"""
        chart_config = {
            "type": "bar",
            "title": title,
            "data": data,
            "xField": x_field,
            "yField": y_field
        }
        return self.create_chart(dashboard_id, chart_config)
    
    def create_radar_chart(self, dashboard_id: str, title: str,
                          dimensions: List[str], scores: List[float]) -> Optional[str]:
        """创建雷达图（用于健康度多维度展示）"""
        data = [
            {"dimension": dim, "score": score}
            for dim, score in zip(dimensions, scores)
        ]
        
        chart_config = {
            "type": "radar",
            "title": title,
            "data": data,
            "xField": "dimension",
            "yField": "score"
        }
        return self.create_chart(dashboard_id, chart_config)
    
    def update_dashboard_data(self, dashboard_id: str, data: Dict) -> bool:
        """更新仪表板数据"""
        if not self.token:
            return False
        
        try:
            url = f"{self.base_url}/api/panel/data/update"
            payload = {
                "panelId": dashboard_id,
                "data": json.dumps(data)
            }
            
            response = self.session.post(url, json=payload, timeout=10)
            response.raise_for_status()
            
            _logger.debug(f"更新仪表板数据成功: {dashboard_id}")
            return True
            
        except Exception as e:
            _logger.error(f"更新仪表板数据失败: {str(e)}")
            return False



