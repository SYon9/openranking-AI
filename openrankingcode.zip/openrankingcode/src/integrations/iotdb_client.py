"""
IoTDB时序数据库客户端集成
用于存储和查询工业设备时序数据
"""
from typing import Dict, List, Optional
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

try:
    from iotdb.Session import Session
    from iotdb.utils.IoTDBConstants import TSDataType, TSEncoding, Compressor
    IOTDB_AVAILABLE = True
except ImportError:
    IOTDB_AVAILABLE = False

from src.config import IOTDB_HOST, IOTDB_PORT, IOTDB_USER, IOTDB_PASSWORD
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class IoTDBClient:
    """IoTDB客户端"""
    
    def __init__(self):
        self.host = IOTDB_HOST
        self.port = IOTDB_PORT
        self.user = IOTDB_USER
        self.password = IOTDB_PASSWORD
        self.session = None
        
        if IOTDB_AVAILABLE:
            try:
                self.session = Session(
                    self.host,
                    self.port,
                    self.user,
                    self.password
                )
                self.session.open(False)
                _logger.info("IoTDB连接成功")
            except Exception as e:
                _logger.warning(f"IoTDB连接失败: {str(e)}")
                self.session = None
        else:
            _logger.warning("IoTDB库未安装，使用模拟模式")
    
    def create_storage_group(self, group_path: str) -> bool:
        """创建存储组"""
        if not self.session:
            return False
        
        try:
            self.session.create_storage_group(group_path)
            _logger.info(f"创建存储组成功: {group_path}")
            return True
        except Exception as e:
            _logger.error(f"创建存储组失败: {str(e)}")
            return False
    
    def create_timeseries(self, device_path: str, measurement: str,
                         data_type: str = "FLOAT") -> bool:
        """
        创建时间序列
        
        Args:
            device_path: 设备路径，如 "root.sg.project.repo"
            measurement: 测量名称，如 "openrank"
            data_type: 数据类型，FLOAT, DOUBLE, INT32, INT64, TEXT, BOOLEAN
        """
        if not self.session:
            return False
        
        try:
            ts_type_map = {
                "FLOAT": TSDataType.FLOAT,
                "DOUBLE": TSDataType.DOUBLE,
                "INT32": TSDataType.INT32,
                "INT64": TSDataType.INT64,
                "TEXT": TSDataType.TEXT,
                "BOOLEAN": TSDataType.BOOLEAN
            }
            
            ts_type = ts_type_map.get(data_type.upper(), TSDataType.FLOAT)
            
            self.session.create_timeseries(
                f"{device_path}.{measurement}",
                ts_type,
                TSEncoding.PLAIN,
                Compressor.SNAPPY
            )
            _logger.debug(f"创建时间序列成功: {device_path}.{measurement}")
            return True
        except Exception as e:
            _logger.error(f"创建时间序列失败: {str(e)}")
            return False
    
    def insert_data(self, device_path: str, measurement: str, 
                   value: float, timestamp: Optional[datetime] = None) -> bool:
        """
        插入时序数据
        
        Args:
            device_path: 设备路径
            measurement: 测量名称
            value: 数值
            timestamp: 时间戳，默认当前时间
        """
        if not self.session:
            return False
        
        try:
            if timestamp is None:
                timestamp = datetime.now()
            
            # 转换为毫秒时间戳
            ts_millis = int(timestamp.timestamp() * 1000)
            
            self.session.insert_record(
                device_path,
                ts_millis,
                [measurement],
                [TSDataType.FLOAT],
                [value]
            )
            _logger.debug(f"插入数据成功: {device_path}.{measurement} = {value}")
            return True
        except Exception as e:
            _logger.error(f"插入数据失败: {str(e)}")
            return False
    
    def query_data(self, device_path: str, measurement: str,
                  start_time: datetime, end_time: datetime) -> List[Dict]:
        """
        查询时序数据
        
        Args:
            device_path: 设备路径
            measurement: 测量名称
            start_time: 开始时间
            end_time: 结束时间
        
        Returns:
            查询结果列表
        """
        if not self.session:
            return []
        
        try:
            start_ts = int(start_time.timestamp() * 1000)
            end_ts = int(end_time.timestamp() * 1000)
            
            query_sql = f"""
                SELECT {measurement}
                FROM {device_path}
                WHERE time >= {start_ts} AND time <= {end_ts}
            """
            
            result = self.session.execute_query_statement(query_sql)
            
            data = []
            while result.has_next():
                row = result.next()
                data.append({
                    "timestamp": datetime.fromtimestamp(row.get_timestamp() / 1000),
                    "value": row.get_fields()[0].get_value()
                })
            
            result.close_operation_handle()
            return data
            
        except Exception as e:
            _logger.error(f"查询数据失败: {str(e)}")
            return []
    
    def save_project_metrics(self, repo: str, metrics: Dict[str, float],
                            timestamp: Optional[datetime] = None) -> bool:
        """
        保存项目指标到IoTDB
        
        Args:
            repo: 仓库名称
            metrics: 指标字典
            timestamp: 时间戳
        """
        if not self.session:
            return False
        
        try:
            # 创建存储组（如果不存在）
            group_path = "root.sg.projects"
            try:
                self.create_storage_group(group_path)
            except:
                pass  # 可能已存在
            
            device_path = f"{group_path}.{repo.replace('/', '_')}"
            
            # 插入各指标
            for metric_name, value in metrics.items():
                self.create_timeseries(device_path, metric_name)
                self.insert_data(device_path, metric_name, value, timestamp)
            
            _logger.info(f"项目指标已保存到IoTDB: {repo}")
            return True
            
        except Exception as e:
            _logger.error(f"保存项目指标失败: {str(e)}")
            return False
    
    def close(self):
        """关闭连接"""
        if self.session:
            try:
                self.session.close()
                _logger.info("IoTDB连接已关闭")
            except:
                pass



