"""
OpenDigger客户端集成
扩展OpenDigger的功能，实现多场景专属指标计算
"""
import requests
from typing import Dict, List, Optional
from datetime import datetime, timedelta

from src.config import OPENDIGGER_API_URL, OPENDIGGER_API_KEY
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class OpenDiggerClient:
    """OpenDigger客户端"""
    
    def __init__(self):
        self.base_url = OPENDIGGER_API_URL
        self.api_key = OPENDIGGER_API_KEY
        self.session = requests.Session()
        
        if self.api_key:
            self.session.headers.update({"Authorization": f"Bearer {self.api_key}"})
        
        self.session.headers.update({
            "Content-Type": "application/json",
            "User-Agent": "IndusOpsAI/1.0"
        })
    
    def get_project_openrank(self, repo: str, start_date: Optional[str] = None,
                           end_date: Optional[str] = None) -> Dict:
        """获取项目OpenRank数据"""
        try:
            if not start_date:
                start_date = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
            if not end_date:
                end_date = datetime.now().strftime("%Y-%m-%d")
            
            url = f"{self.base_url}/api/v1/repos/{repo}/openrank"
            params = {
                "startDate": start_date,
                "endDate": end_date,
                "period": "month"
            }
            
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            _logger.debug(f"获取 {repo} 的OpenRank数据成功")
            return data
            
        except Exception as e:
            _logger.error(f"获取OpenRank数据失败: {str(e)}")
            return {}
    
    def get_contributors(self, repo: str) -> List[Dict]:
        """获取项目贡献者列表"""
        try:
            url = f"{self.base_url}/api/v1/repos/{repo}/contributors"
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            contributors = data.get("data", [])
            _logger.debug(f"获取 {repo} 的贡献者数据成功，共 {len(contributors)} 人")
            return contributors
            
        except Exception as e:
            _logger.error(f"获取贡献者数据失败: {str(e)}")
            return []
    
    def calculate_collaboration_network(self, repo: str) -> Dict:
        """
        计算协作网络数据
        基于贡献者之间的协作关系构建网络图谱
        """
        try:
            contributors = self.get_contributors(repo)
            
            # 简化版协作网络分析
            # 实际应分析PR review、issue讨论等互动数据
            network = {
                "nodes": [],
                "edges": [],
                "network_metrics": {}
            }
            
            for contributor in contributors:
                network["nodes"].append({
                    "id": contributor.get("id", ""),
                    "label": contributor.get("login", ""),
                    "value": contributor.get("contributions", 0),
                    "openrank": contributor.get("openrank", 0)
                })
            
            # 计算网络指标
            network["network_metrics"] = {
                "node_count": len(network["nodes"]),
                "edge_count": len(network["edges"]),
                "density": len(network["edges"]) / (len(network["nodes"]) * (len(network["nodes"]) - 1)) if len(network["nodes"]) > 1 else 0
            }
            
            return network
            
        except Exception as e:
            _logger.error(f"计算协作网络失败: {str(e)}")
            return {"nodes": [], "edges": [], "network_metrics": {}}
    
    def get_project_activity(self, repo: str, start_date: Optional[str] = None,
                           end_date: Optional[str] = None) -> Dict:
        """获取项目活跃度指标"""
        try:
            if not start_date:
                start_date = (datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d")
            if not end_date:
                end_date = datetime.now().strftime("%Y-%m-%d")
            
            url = f"{self.base_url}/api/v1/repos/{repo}/activity"
            params = {
                "startDate": start_date,
                "endDate": end_date
            }
            
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            return response.json()
            
        except Exception as e:
            _logger.error(f"获取活跃度数据失败: {str(e)}")
            return {}



