"""
MaxKB智能问答客户端集成
用于知识库问答和自然语言交互
"""
import requests
from typing import Dict, List, Optional
import json

from src.config import MAXKB_API_URL, MAXKB_API_KEY
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class MaxKBClient:
    """MaxKB客户端"""
    
    def __init__(self):
        self.base_url = MAXKB_API_URL.rstrip('/')
        self.api_key = MAXKB_API_KEY
        self.session = requests.Session()
        
        if self.api_key:
            self.session.headers.update({
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            })
    
    def ask(self, question: str, knowledge_base_id: Optional[str] = None,
           context: Optional[Dict] = None) -> Dict:
        """
        提问
        
        Args:
            question: 问题
            knowledge_base_id: 知识库ID
            context: 上下文信息
        
        Returns:
            回答结果
        """
        try:
            url = f"{self.base_url}/api/chat/completions"
            
            data = {
                "question": question,
                "stream": False
            }
            
            if knowledge_base_id:
                data["knowledge_base_id"] = knowledge_base_id
            
            if context:
                data["context"] = context
            
            response = self.session.post(url, json=data, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            _logger.debug(f"MaxKB问答成功: {question[:50]}...")
            return result
            
        except Exception as e:
            _logger.error(f"MaxKB问答失败: {str(e)}")
            return {
                "answer": "抱歉，暂时无法回答问题，请稍后重试。",
                "sources": [],
                "error": str(e)
            }
    
    def create_knowledge_base(self, name: str, description: str = "") -> Optional[str]:
        """创建知识库"""
        try:
            url = f"{self.base_url}/api/knowledge/base/create"
            data = {
                "name": name,
                "description": description
            }
            
            response = self.session.post(url, json=data, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            kb_id = result.get("data", {}).get("id")
            
            if kb_id:
                _logger.info(f"创建知识库成功: {name} (ID: {kb_id})")
                return kb_id
            return None
            
        except Exception as e:
            _logger.error(f"创建知识库失败: {str(e)}")
            return None
    
    def add_document(self, knowledge_base_id: str, content: str,
                    metadata: Optional[Dict] = None) -> bool:
        """向知识库添加文档"""
        try:
            url = f"{self.base_url}/api/knowledge/document/add"
            data = {
                "knowledge_base_id": knowledge_base_id,
                "content": content
            }
            
            if metadata:
                data["metadata"] = metadata
            
            response = self.session.post(url, json=data, timeout=10)
            response.raise_for_status()
            
            _logger.debug(f"添加文档成功: {knowledge_base_id}")
            return True
            
        except Exception as e:
            _logger.error(f"添加文档失败: {str(e)}")
            return False
    
    def query_with_visualization_hint(self, question: str,
                                     project_data: Optional[Dict] = None) -> Dict:
        """
        提问并返回可视化提示
        
        Args:
            question: 问题
            project_data: 项目数据（用于上下文）
        
        Returns:
            包含回答和可视化建议的结果
        """
        # 构建上下文
        context = {}
        if project_data:
            context["project"] = project_data.get("repo", "")
            context["metrics"] = project_data.get("metrics", {})
        
        # 调用问答接口
        answer_result = self.ask(question, context=context)
        
        # 分析问题类型，提供可视化建议
        viz_type = self._detect_visualization_type(question)
        
        result = {
            "answer": answer_result.get("answer", ""),
            "sources": answer_result.get("sources", []),
            "visualization": {
                "type": viz_type,
                "suggestion": self._get_viz_suggestion(viz_type)
            }
        }
        
        return result
    
    def _detect_visualization_type(self, question: str) -> str:
        """检测问题类型，返回推荐的可视化类型"""
        question_lower = question.lower()
        
        if any(word in question_lower for word in ["趋势", "变化", "时间", "历史"]):
            return "line"
        elif any(word in question_lower for word in ["排名", "对比", "比较"]):
            return "bar"
        elif any(word in question_lower for word in ["分布", "占比", "比例"]):
            return "pie"
        elif any(word in question_lower for word in ["关系", "网络", "关联"]):
            return "network"
        elif any(word in question_lower for word in ["热力", "密度"]):
            return "heatmap"
        else:
            return "table"
    
    def _get_viz_suggestion(self, viz_type: str) -> str:
        """获取可视化建议"""
        suggestions = {
            "line": "建议使用折线图展示趋势变化",
            "bar": "建议使用柱状图进行排名对比",
            "pie": "建议使用饼图展示分布占比",
            "network": "建议使用网络图展示关系",
            "heatmap": "建议使用热力图展示密度分布",
            "table": "建议使用表格展示详细数据"
        }
        return suggestions.get(viz_type, "建议使用表格展示数据")



