"""
Flask应用主入口
"""
from flask import Flask, render_template
from flask_cors import CORS
from flask_restful import Api
from flask_jwt_extended import JWTManager
import os

from src.config import JWT_SECRET_KEY, JWT_ACCESS_TOKEN_EXPIRES
from src.api.routes import initialize_routes
from src.utils.logger import get_logger

_logger = get_logger(__name__)


def create_app():
    """创建Flask应用"""
    # 设置模板目录
    template_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
    app = Flask(__name__, template_folder=template_dir)
    
    # 配置
    app.config["JWT_SECRET_KEY"] = JWT_SECRET_KEY
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = JWT_ACCESS_TOKEN_EXPIRES
    
    # 启用CORS
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    
    # 初始化JWT
    jwt = JWTManager(app)
    
    # 初始化API
    api = Api(app, prefix="/api/v1")
    initialize_routes(api)
    
    @app.route("/")
    def index():
        """首页 - 返回前端界面"""
        return render_template("index.html")
    
    @app.route("/api/info")
    def api_info():
        """API信息"""
        return {
            "name": "IndusOpsAI",
            "version": "1.0.0",
            "status": "running",
            "api_version": "v1",
            "base_url": "/api/v1"
        }
    
    @app.route("/health")
    def health():
        return {"status": "healthy"}
    
    _logger.info("Flask应用初始化完成")
    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=True)



