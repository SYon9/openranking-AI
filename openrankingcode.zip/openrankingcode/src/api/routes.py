"""
API路由定义
"""
from flask_restful import Resource, reqparse
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from src.services.project_service import ProjectService
from src.services.developer_service import DeveloperService
from src.services.matching_service import MatchingService
from src.services.qa_service import QAService
from src.utils.logger import get_logger

_logger = get_logger(__name__)


def initialize_routes(api):
    """初始化所有路由"""
    
    # 认证相关
    api.add_resource(LoginResource, "/auth/login")
    api.add_resource(RegisterResource, "/auth/register")
    
    # 项目相关
    api.add_resource(ProjectListResource, "/projects")
    api.add_resource(ProjectDetailResource, "/projects/<string:repo>")
    api.add_resource(ProjectHealthResource, "/projects/<string:repo>/health")
    api.add_resource(ProjectMetricsResource, "/projects/<string:repo>/metrics")
    
    # 开发者相关
    api.add_resource(DeveloperProfileResource, "/developers/<string:developer_id>")
    api.add_resource(DeveloperPathResource, "/developers/<string:developer_id>/path")
    
    # 匹配相关
    api.add_resource(MatchProjectContributorResource, "/match/project-contributor")
    api.add_resource(MatchContributorContributorResource, "/match/contributor-contributor")
    
    # 问答相关
    api.add_resource(QAResource, "/qa/ask")
    
    _logger.info("API路由初始化完成")


class LoginResource(Resource):
    """登录接口"""
    
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("username", type=str, required=True)
        parser.add_argument("password", type=str, required=True)
        args = parser.parse_args()
        
        # 简化认证逻辑（实际应使用数据库验证）
        if args["username"] and args["password"]:
            access_token = create_access_token(identity=args["username"])
            return {
                "access_token": access_token,
                "token_type": "Bearer"
            }, 200
        return {"error": "Invalid credentials"}, 401


class RegisterResource(Resource):
    """注册接口"""
    
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("username", type=str, required=True)
        parser.add_argument("password", type=str, required=True)
        parser.add_argument("email", type=str)
        args = parser.parse_args()
        
        # 简化注册逻辑
        return {"message": "Registration successful", "username": args["username"]}, 201


class ProjectListResource(Resource):
    """项目列表"""
    
    @jwt_required(optional=True)
    def get(self):
        service = ProjectService()
        projects = service.list_projects()
        return {"projects": projects}, 200
    
    @jwt_required()
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("repo", type=str, required=True)
        args = parser.parse_args()
        
        service = ProjectService()
        result = service.add_project(args["repo"])
        return result, 201


class ProjectDetailResource(Resource):
    """项目详情"""
    
    def get(self, repo: str):
        service = ProjectService()
        project = service.get_project(repo)
        if project:
            return project, 200
        return {"error": "Project not found"}, 404


class ProjectHealthResource(Resource):
    """项目健康度评估"""
    
    def get(self, repo: str):
        service = ProjectService()
        health = service.assess_health(repo)
        if health:
            return health, 200
        return {"error": "Health assessment failed"}, 500


class ProjectMetricsResource(Resource):
    """项目指标"""
    
    def get(self, repo: str):
        service = ProjectService()
        metrics = service.get_metrics(repo)
        return {"metrics": metrics}, 200


class DeveloperProfileResource(Resource):
    """开发者档案"""
    
    def get(self, developer_id: str):
        service = DeveloperService()
        profile = service.get_profile(developer_id)
        if profile:
            return profile, 200
        return {"error": "Developer not found"}, 404


class DeveloperPathResource(Resource):
    """开发者贡献路径"""
    
    def get(self, developer_id: str):
        parser = reqparse.RequestParser()
        parser.add_argument("project_repo", type=str)
        parser.add_argument("target_openrank", type=float)
        args = parser.parse_args()
        
        service = DeveloperService()
        path = service.plan_path(developer_id, args.get("project_repo"), args.get("target_openrank"))
        if path:
            return path, 200
        return {"error": "Path planning failed"}, 500


class MatchProjectContributorResource(Resource):
    """项目-贡献者匹配"""
    
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("project_repo", type=str, required=True)
        parser.add_argument("top_k", type=int, default=10)
        args = parser.parse_args()
        
        service = MatchingService()
        matches = service.match_project_contributor(args["project_repo"], args["top_k"])
        return {"matches": matches}, 200


class MatchContributorContributorResource(Resource):
    """贡献者-贡献者匹配（协作伙伴推荐）"""
    
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("contributor_id", type=str, required=True)
        parser.add_argument("top_k", type=int, default=10)
        args = parser.parse_args()
        
        service = MatchingService()
        matches = service.match_contributor_contributor(args["contributor_id"], args["top_k"])
        return {"matches": matches}, 200


class QAResource(Resource):
    """智能问答"""
    
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument("question", type=str, required=True)
        parser.add_argument("project_repo", type=str)
        args = parser.parse_args()
        
        service = QAService()
        result = service.ask(args["question"], args.get("project_repo"))
        return result, 200



