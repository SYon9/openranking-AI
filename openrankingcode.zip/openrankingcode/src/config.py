"""
配置管理模块
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 项目根目录
BASE_DIR = Path(__file__).parent.parent

# 数据库配置
SQLITE_DB_PATH = os.getenv("SQLITE_DB_PATH", str(BASE_DIR / "data" / "indusopsai.db"))
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
REDIS_DB = int(os.getenv("REDIS_DB", 0))

# IoTDB配置
IOTDB_HOST = os.getenv("IOTDB_HOST", "localhost")
IOTDB_PORT = int(os.getenv("IOTDB_PORT", 6667))
IOTDB_USER = os.getenv("IOTDB_USER", "root")
IOTDB_PASSWORD = os.getenv("IOTDB_PASSWORD", "root")

# OpenDigger配置
OPENDIGGER_API_URL = os.getenv("OPENDIGGER_API_URL", "https://api.opendigger.cn")
OPENDIGGER_API_KEY = os.getenv("OPENDIGGER_API_KEY", "")

# DataEase配置
DATAEASE_API_URL = os.getenv("DATAEASE_API_URL", "http://localhost:8080")
DATAEASE_USERNAME = os.getenv("DATAEASE_USERNAME", "admin")
DATAEASE_PASSWORD = os.getenv("DATAEASE_PASSWORD", "admin")

# MaxKB配置
MAXKB_API_URL = os.getenv("MAXKB_API_URL", "http://localhost:8081")
MAXKB_API_KEY = os.getenv("MAXKB_API_KEY", "")

# JWT配置
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "indusopsai-secret-key-change-in-production")
JWT_ACCESS_TOKEN_EXPIRES = int(os.getenv("JWT_ACCESS_TOKEN_EXPIRES", 3600))

# 消息队列配置
RABBITMQ_HOST = os.getenv("RABBITMQ_HOST", "localhost")
RABBITMQ_PORT = int(os.getenv("RABBITMQ_PORT", 5672))
RABBITMQ_USER = os.getenv("RABBITMQ_USER", "guest")
RABBITMQ_PASSWORD = os.getenv("RABBITMQ_PASSWORD", "guest")

# 日志配置
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE = os.getenv("LOG_FILE", str(BASE_DIR / "logs" / "indusopsai.log"))

# 数据目录
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
CACHE_DIR = DATA_DIR / "cache"
MODELS_DIR = BASE_DIR / "models"
LOGS_DIR = BASE_DIR / "logs"

# 创建必要的目录
for directory in [DATA_DIR, RAW_DATA_DIR, PROCESSED_DATA_DIR, CACHE_DIR, MODELS_DIR, LOGS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)



