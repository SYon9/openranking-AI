"""
开发者服务
"""
from typing import Dict, Optional
from src.core.path_planning import PathPlanningModel
from src.data_layer.storage import DataStorage
from src.services.project_service import ProjectService
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class DeveloperService:
    """开发者服务"""
    
    def __init__(self):
        self.storage = DataStorage()
        self.path_planner = PathPlanningModel()
        self.project_service = ProjectService()
    
    def get_profile(self, developer_id: str) -> Optional[Dict]:
        """获取开发者档案"""
        # 从存储中获取开发者数据
        # 简化实现
        return {
            "id": developer_id,
            "openrank": 0,
            "contributions": 0,
            "skill_tags": []
        }
    
    def plan_path(self, developer_id: str, project_repo: Optional[str] = None,
                 target_openrank: Optional[float] = None) -> Optional[Dict]:
        """规划贡献路径"""
        try:
            # 获取开发者数据
            developer_data = self.get_profile(developer_id)
            
            # 获取项目数据（如果指定）
            project_data = None
            if project_repo:
                project_data = self.project_service.get_project(project_repo)
            
            if not project_data:
                # 使用默认项目数据
                project_data = {"metrics": {}, "contributors": []}
            
            # 规划路径
            path = self.path_planner.plan_contribution_path(
                developer_data,
                project_data,
                target_openrank
            )
            
            return path
        except Exception as e:
            _logger.error(f"路径规划失败: {str(e)}")
            return None



