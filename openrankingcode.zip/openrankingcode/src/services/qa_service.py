"""
智能问答服务
"""
from typing import Dict, Optional
from src.integrations.maxkb_client import MaxKBClient
from src.services.project_service import ProjectService
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class QAService:
    """智能问答服务"""
    
    def __init__(self):
        self.maxkb = MaxKBClient()
        self.project_service = ProjectService()
    
    def ask(self, question: str, project_repo: Optional[str] = None) -> Dict:
        """提问"""
        try:
            # 获取项目数据（如果指定）
            project_data = None
            if project_repo:
                project_data = self.project_service.get_project(project_repo)
            
            # 调用MaxKB问答
            result = self.maxkb.query_with_visualization_hint(question, project_data)
            
            return result
        except Exception as e:
            _logger.error(f"问答失败: {str(e)}")
            return {
                "answer": "抱歉，暂时无法回答问题。",
                "error": str(e)
            }



