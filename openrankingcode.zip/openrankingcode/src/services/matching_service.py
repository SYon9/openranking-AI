"""
匹配服务
"""
from typing import Dict, List
from src.core.matching_engine import GNNMatchingEngine
from src.data_layer.storage import DataStorage
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class MatchingService:
    """匹配服务"""
    
    def __init__(self):
        self.storage = DataStorage()
        self.matching_engine = GNNMatchingEngine()
    
    def match_project_contributor(self, project_repo: str, top_k: int = 10) -> List[Dict]:
        """匹配项目与贡献者"""
        try:
            # 获取项目数据
            project_data = self.storage.get_project(project_repo)
            if not project_data:
                return []
            
            # 获取贡献者列表
            contributors = project_data.get("contributors", [])
            
            # 简化匹配逻辑（实际应使用GNN模型）
            matches = []
            for contributor in contributors[:top_k]:
                matches.append({
                    "contributor_id": contributor.get("id"),
                    "login": contributor.get("login"),
                    "match_score": contributor.get("openrank", 0) / 100,  # 简化评分
                    "contributions": contributor.get("contributions", 0)
                })
            
            # 按匹配度排序
            matches.sort(key=lambda x: x["match_score"], reverse=True)
            
            return matches[:top_k]
        except Exception as e:
            _logger.error(f"匹配失败: {str(e)}")
            return []
    
    def match_contributor_contributor(self, contributor_id: str, top_k: int = 10) -> List[Dict]:
        """匹配贡献者与贡献者"""
        # 简化实现
        return []



