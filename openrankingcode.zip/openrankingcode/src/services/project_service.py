"""
项目服务
"""
from typing import Dict, List, Optional
from src.data_layer.collector import DataCollector
from src.data_layer.processor import DataProcessor
from src.data_layer.storage import DataStorage
from src.core.health_assessment import HealthAssessmentModel
from src.core.forecast_model import LSTMForecastModel
from src.integrations.opendigger_client import OpenDiggerClient
from src.utils.logger import get_logger

_logger = get_logger(__name__)


class ProjectService:
    """项目服务"""
    
    def __init__(self):
        self.collector = DataCollector()
        self.processor = DataProcessor()
        self.storage = DataStorage()
        self.opendigger = OpenDiggerClient()
        self.health_model = HealthAssessmentModel()
    
    def add_project(self, repo: str) -> Dict:
        """添加项目并采集数据"""
        try:
            # 采集数据
            raw_data = self.collector.collect_project_metrics(repo)
            
            # 处理数据
            processed_data = self.processor.process_project_data(raw_data)
            
            # 存储数据
            self.storage.save_project(processed_data)
            
            return {
                "repo": repo,
                "status": "success",
                "message": "项目添加成功"
            }
        except Exception as e:
            _logger.error(f"添加项目失败: {str(e)}")
            return {
                "repo": repo,
                "status": "error",
                "message": str(e)
            }
    
    def get_project(self, repo: str) -> Optional[Dict]:
        """获取项目数据"""
        return self.storage.get_project(repo)
    
    def list_projects(self) -> List[str]:
        """列出所有项目"""
        # 简化实现，实际应从数据库查询
        return []
    
    def assess_health(self, repo: str) -> Optional[Dict]:
        """评估项目健康度"""
        try:
            project_data = self.storage.get_project(repo)
            if not project_data:
                return None
            
            # 健康度评估
            health_result = self.health_model.calculate_health_score(project_data)
            
            return health_result
        except Exception as e:
            _logger.error(f"健康度评估失败: {str(e)}")
            return None
    
    def get_metrics(self, repo: str) -> Dict:
        """获取项目指标"""
        project_data = self.storage.get_project(repo)
        if project_data:
            return project_data.get("metrics", {})
        return {}



