# IndusOpsAI 使用指南

## 快速开始

### 1. 启动服务

**开发环境：**
```bash
python run.py
```

**生产环境：**
```bash
# Linux/macOS
gunicorn -c gunicorn.conf.py src.api.app:create_app

# Windows
python scripts\start_prod.py
```

服务启动后，默认运行在 `http://localhost:5000`

### 2. 访问前端界面

在浏览器中打开：
```
http://localhost:5000
```

### 3. 配置服务地址

1. 在页面顶部的输入框中输入服务地址（默认：`http://localhost:5000`）
2. 点击"保存配置"按钮
3. 点击"测试连接"验证服务是否正常

## 功能模块说明

### 📊 概览

显示系统状态、API版本和服务健康状态。

### 📁 项目管理

#### 获取项目详情
- **输入**：项目仓库（格式：`owner/repo`，例如：`apache/iotdb`）
- **功能**：获取项目的详细信息，包括指标、贡献者等

#### 获取项目健康度
- **输入**：项目仓库
- **功能**：评估项目的健康度，包括：
  - 总体评分
  - 各维度得分（代码活跃度、Issue效能、贡献者生态等）
  - 风险识别
  - 优化建议

#### 获取项目指标
- **输入**：项目仓库
- **功能**：获取项目的各项指标数据

#### 获取项目列表
- **功能**：获取所有已添加的项目列表

### 👥 开发者

#### 获取开发者档案
- **输入**：开发者ID
- **功能**：获取开发者的详细信息，包括：
  - OpenRank分数
  - 贡献数量
  - 技能标签
  - 参与的项目

#### 获取成长路径
- **输入**：
  - 开发者ID（必需）
  - 项目仓库（可选）
  - 目标OpenRank（可选）
- **功能**：为开发者规划个性化的成长路径，包括：
  - 推荐任务
  - 成长里程碑
  - 技能提升建议

### 🤝 智能匹配

#### 项目-贡献者匹配
- **输入**：
  - 项目仓库（必需）
  - 返回数量（top_k，默认10）
- **功能**：为项目推荐合适的贡献者

#### 贡献者-贡献者匹配
- **输入**：
  - 贡献者ID（必需）
  - 返回数量（top_k，默认10）
- **功能**：为贡献者推荐协作伙伴

### 💬 智能问答

- **输入**：
  - 问题（必需，自然语言）
  - 项目仓库（可选）
- **功能**：使用自然语言查询项目数据，获得：
  - 智能回答
  - 数据来源
  - 可视化建议

### 🧪 测试用例

提供完整的API测试用例，包括：
- 健康检查测试
- 项目API测试
- 开发者API测试
- 匹配API测试
- 问答API测试
- 一键运行所有测试

## API使用示例

### 使用 curl 命令

#### 1. 健康检查
```bash
curl http://localhost:5000/health
```

#### 2. 获取项目健康度
```bash
curl http://localhost:5000/api/v1/projects/apache/iotdb/health
```

#### 3. 获取开发者档案
```bash
curl http://localhost:5000/api/v1/developers/dev123
```

#### 4. 智能问答
```bash
curl -X POST http://localhost:5000/api/v1/qa/ask \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Apache IoTDB的健康度如何？",
    "project_repo": "apache/iotdb"
  }'
```

#### 5. 项目-贡献者匹配
```bash
curl -X POST http://localhost:5000/api/v1/match/project-contributor \
  -H "Content-Type: application/json" \
  -d '{
    "project_repo": "apache/iotdb",
    "top_k": 10
  }'
```

### 使用 Python requests

```python
import requests

# 基础URL
BASE_URL = "http://localhost:5000/api/v1"

# 获取项目健康度
response = requests.get(f"{BASE_URL}/projects/apache/iotdb/health")
print(response.json())

# 智能问答
response = requests.post(
    f"{BASE_URL}/qa/ask",
    json={
        "question": "Apache IoTDB的健康度如何？",
        "project_repo": "apache/iotdb"
    }
)
print(response.json())
```

## 常见问题

### Q: 前端界面无法访问？

A: 请检查：
1. 服务是否已启动
2. 服务地址是否正确
3. 防火墙是否阻止了端口5000
4. 浏览器控制台是否有错误信息

### Q: API调用返回错误？

A: 请检查：
1. 服务地址配置是否正确
2. API路径是否正确
3. 请求参数格式是否正确
4. 查看浏览器控制台的错误信息

### Q: 如何查看详细的API文档？

A: 查看 [API文档](docs/API.md) 获取完整的API说明。

### Q: 测试用例全部失败？

A: 可能原因：
1. 服务未启动
2. 服务地址配置错误
3. 某些功能需要先添加项目数据
4. 查看具体错误信息进行排查

## 高级功能

### 认证使用

某些API需要JWT认证：

```bash
# 1. 登录获取token
curl -X POST http://localhost:5000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "user123",
    "password": "password123"
  }'

# 2. 使用token访问受保护的API
curl -X POST http://localhost:5000/api/v1/projects \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "repo": "apache/iotdb"
  }'
```

### 自定义服务地址

如果服务运行在其他地址或端口，只需在前端界面修改服务地址即可，配置会自动保存到浏览器本地存储。

## 技术支持

- 查看 [README.md](README.md) 了解项目详情
- 查看 [API文档](docs/API.md) 了解API详情
- 查看 [部署文档](docs/DEPLOYMENT.md) 了解部署详情
- 提交 Issue: https://github.com/your-org/IndusOpsAI/issues



