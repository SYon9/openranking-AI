# IndusOpsAI 测试用例文档

## 测试环境准备

1. 启动服务：
```bash
python run.py
```

2. 确保服务运行在 `http://localhost:5000`

3. 打开前端界面：`http://localhost:5000`

## 测试用例列表

### 1. 系统健康检查测试

**测试目标**：验证服务基本功能正常

**测试步骤**：
1. 在前端界面输入服务地址：`http://localhost:5000`
2. 点击"测试连接"按钮
3. 点击"概览"标签页，查看系统状态

**预期结果**：
- 连接测试成功，显示 `{"status": "healthy"}`
- 系统状态显示"在线"
- API版本显示"1.0.0"
- 服务健康显示"健康"

**API测试**：
```bash
curl http://localhost:5000/health
```

**预期响应**：
```json
{
  "status": "healthy"
}
```

---

### 2. 项目详情API测试

**测试目标**：验证项目详情查询功能

**测试步骤**：
1. 切换到"项目管理"标签页
2. 输入项目仓库：`apache/iotdb`
3. 点击"获取项目详情"按钮

**预期结果**：
- 返回项目详细信息
- 包含项目名称、指标、贡献者等信息

**API测试**：
```bash
curl http://localhost:5000/api/v1/projects/apache/iotdb
```

**预期响应**：
```json
{
  "repo": "apache/iotdb",
  "name": "iotdb",
  "metrics": {...},
  "contributors": [...]
}
```

---

### 3. 项目健康度评估测试

**测试目标**：验证健康度评估功能

**测试步骤**：
1. 在"项目管理"标签页
2. 输入项目仓库：`apache/iotdb`
3. 点击"获取健康度"按钮

**预期结果**：
- 返回健康度评估结果
- 包含总体评分、各维度得分、风险和建议

**API测试**：
```bash
curl http://localhost:5000/api/v1/projects/apache/iotdb/health
```

**预期响应**：
```json
{
  "overall_score": 85.5,
  "dimension_scores": {
    "code_activity": 0.8,
    "issue_efficiency": 0.75,
    "contributor_ecology": 0.82,
    "collaboration_quality": 0.88,
    "compliance_security": 0.9
  },
  "risks": [],
  "suggestions": [...]
}
```

---

### 4. 项目指标查询测试

**测试目标**：验证项目指标查询功能

**测试步骤**：
1. 在"项目管理"标签页
2. 输入项目仓库：`apache/iotdb`
3. 点击"获取指标"按钮

**预期结果**：
- 返回项目各项指标数据

**API测试**：
```bash
curl http://localhost:5000/api/v1/projects/apache/iotdb/metrics
```

---

### 5. 项目列表查询测试

**测试目标**：验证项目列表查询功能

**测试步骤**：
1. 在"项目管理"标签页
2. 点击"获取项目列表"按钮

**预期结果**：
- 返回项目列表（可能为空数组）

**API测试**：
```bash
curl http://localhost:5000/api/v1/projects
```

---

### 6. 开发者档案查询测试

**测试目标**：验证开发者信息查询功能

**测试步骤**：
1. 切换到"开发者"标签页
2. 输入开发者ID：`dev123`
3. 点击"获取开发者档案"按钮

**预期结果**：
- 返回开发者详细信息
- 或返回404错误（如果开发者不存在）

**API测试**：
```bash
curl http://localhost:5000/api/v1/developers/dev123
```

**预期响应（成功）**：
```json
{
  "id": "dev123",
  "openrank": 45.2,
  "contributions": 120,
  "skill_tags": ["Python", "Java", "时序数据库"]
}
```

**预期响应（不存在）**：
```json
{
  "error": "Developer not found"
}
```

---

### 7. 开发者成长路径规划测试

**测试目标**：验证路径规划功能

**测试步骤**：
1. 在"开发者"标签页
2. 输入开发者ID：`dev123`
3. （可选）输入项目仓库和目标OpenRank
4. 点击"获取成长路径"按钮

**预期结果**：
- 返回个性化成长路径
- 包含推荐任务、里程碑等

**API测试**：
```bash
curl "http://localhost:5000/api/v1/developers/dev123/path?project_repo=apache/iotdb&target_openrank=100"
```

---

### 8. 项目-贡献者匹配测试

**测试目标**：验证智能匹配功能

**测试步骤**：
1. 切换到"智能匹配"标签页
2. 选择"项目-贡献者匹配"
3. 输入项目仓库：`apache/iotdb`
4. 设置返回数量：10
5. 点击"执行匹配"按钮

**预期结果**：
- 返回匹配的贡献者列表
- 包含匹配分数和贡献信息

**API测试**：
```bash
curl -X POST http://localhost:5000/api/v1/match/project-contributor \
  -H "Content-Type: application/json" \
  -d '{
    "project_repo": "apache/iotdb",
    "top_k": 10
  }'
```

**预期响应**：
```json
{
  "matches": [
    {
      "contributor_id": "contributor123",
      "match_score": 0.85,
      "contributions": 150
    }
  ]
}
```

---

### 9. 贡献者-贡献者匹配测试

**测试目标**：验证协作伙伴推荐功能

**测试步骤**：
1. 在"智能匹配"标签页
2. 选择"贡献者-贡献者匹配"
3. 输入贡献者ID：`contributor123`
4. 设置返回数量：10
5. 点击"执行匹配"按钮

**预期结果**：
- 返回推荐的协作伙伴列表

**API测试**：
```bash
curl -X POST http://localhost:5000/api/v1/match/contributor-contributor \
  -H "Content-Type: application/json" \
  -d '{
    "contributor_id": "contributor123",
    "top_k": 10
  }'
```

---

### 10. 智能问答测试

**测试目标**：验证智能问答功能

**测试步骤**：
1. 切换到"智能问答"标签页
2. 输入问题：`Apache IoTDB的健康度如何？`
3. （可选）输入项目仓库：`apache/iotdb`
4. 点击"提问"按钮

**预期结果**：
- 返回智能回答
- 包含数据来源和可视化建议

**API测试**：
```bash
curl -X POST http://localhost:5000/api/v1/qa/ask \
  -H "Content-Type: application/json" \
  -d '{
    "question": "Apache IoTDB的健康度如何？",
    "project_repo": "apache/iotdb"
  }'
```

**预期响应**：
```json
{
  "answer": "根据数据显示，Apache IoTDB的健康度...",
  "sources": [...],
  "visualization": {
    "type": "line",
    "suggestion": "建议使用折线图展示趋势变化"
  }
}
```

---

### 11. 认证功能测试

**测试目标**：验证JWT认证功能

**测试步骤**：
1. 使用curl或Postman测试登录接口
2. 获取access_token
3. 使用token访问受保护的API

**API测试**：
```bash
# 登录
curl -X POST http://localhost:5000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "testpass"
  }'

# 使用token访问受保护API
curl -X POST http://localhost:5000/api/v1/projects \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "repo": "apache/iotdb"
  }'
```

---

### 12. 批量测试

**测试目标**：验证所有功能是否正常

**测试步骤**：
1. 切换到"测试用例"标签页
2. 点击"运行所有测试"按钮

**预期结果**：
- 所有测试用例执行完成
- 显示每个测试的结果
- 成功或失败的详细信息

---

## 测试数据准备

### 添加测试项目

如果需要测试项目相关功能，可以先添加项目：

```bash
# 需要先登录获取token
TOKEN="YOUR_TOKEN_HERE"

curl -X POST http://localhost:5000/api/v1/projects \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "repo": "apache/iotdb"
  }'
```

### 测试数据示例

**项目仓库示例**：
- `apache/iotdb`
- `apache/spark`
- `tensorflow/tensorflow`

**开发者ID示例**：
- `dev123`
- `contributor456`
- `user789`

---

## 错误处理测试

### 测试无效输入

1. **空项目仓库**：
   - 不输入项目仓库，直接点击查询
   - 预期：显示错误提示

2. **无效格式**：
   - 输入格式错误的项目仓库（如：`invalid-format`）
   - 预期：返回错误信息

3. **不存在的资源**：
   - 查询不存在的项目或开发者
   - 预期：返回404错误

4. **网络错误**：
   - 输入错误的服务地址
   - 预期：显示连接失败

---

## 性能测试

### 响应时间测试

使用前端界面或curl测试各API的响应时间：

```bash
time curl http://localhost:5000/api/v1/projects/apache/iotdb/health
```

**预期**：
- 健康检查：< 100ms
- 项目查询：< 500ms
- 健康度评估：< 2s
- 智能匹配：< 3s
- 智能问答：< 5s

---

## 测试报告模板

### 测试结果记录

| 测试用例 | 状态 | 响应时间 | 备注 |
|---------|------|---------|------|
| 健康检查 | ✓/✗ | XXms | |
| 项目详情 | ✓/✗ | XXms | |
| 健康度评估 | ✓/✗ | XXms | |
| 开发者档案 | ✓/✗ | XXms | |
| 智能匹配 | ✓/✗ | XXms | |
| 智能问答 | ✓/✗ | XXms | |

---

## 故障排查

### 常见问题

1. **所有测试失败**
   - 检查服务是否启动
   - 检查服务地址是否正确
   - 查看服务日志

2. **部分测试失败**
   - 检查相关功能是否正常
   - 检查数据是否存在
   - 查看具体错误信息

3. **响应时间过长**
   - 检查网络连接
   - 检查服务器性能
   - 查看是否有阻塞操作

---

## 自动化测试

可以使用前端界面的"测试用例"功能进行自动化测试，或使用以下Python脚本：

```python
import requests
import json

BASE_URL = "http://localhost:5000/api/v1"

def test_health():
    response = requests.get(f"{BASE_URL.replace('/api/v1', '')}/health")
    assert response.status_code == 200
    print("✓ 健康检查通过")

def test_project_health():
    response = requests.get(f"{BASE_URL}/projects/apache/iotdb/health")
    print(f"项目健康度: {response.status_code}")
    if response.status_code == 200:
        print("✓ 项目健康度查询通过")
    else:
        print(f"✗ 项目健康度查询失败: {response.text}")

if __name__ == "__main__":
    test_health()
    test_project_health()
```



